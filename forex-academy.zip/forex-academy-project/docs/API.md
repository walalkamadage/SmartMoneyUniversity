# API Reference - Supabase Functions

Complete reference for all Supabase helper functions used in the frontend.

All functions are in `src/lib/supabase.js` and return `{ data, error }` objects.

---

## Authentication

### `signUp(email, password, fullName)`
Create a new user account.

```javascript
import { signUp } from '../lib/supabase'

const { data, error } = await signUp(
  'user@example.com',
  'password123',
  'John Doe'
)

if (error) console.error(error.message)
else console.log('Account created!')
```

**Returns**:
- `data.user` - New user object
- `data.session` - Authentication session

---

### `signIn(email, password)`
Log in with email and password.

```javascript
const { data, error } = await signIn(
  'user@example.com',
  'password123'
)

if (error) console.error('Login failed')
else navigate('/dashboard')
```

---

### `signOut()`
Log out the current user.

```javascript
const { error } = await signOut()
if (!error) console.log('Signed out!')
```

---

### `resetPassword(email)`
Send password reset link via email.

```javascript
const { error } = await resetPassword('user@example.com')
if (!error) console.log('Check your email!')
```

---

### `getCurrentUser()`
Get the currently logged-in user.

```javascript
const { user, error } = await getCurrentUser()
if (user) console.log(`Welcome ${user.email}!`)
```

---

## User Profiles

### `getUserProfile(userId)`
Get a user's full profile.

```javascript
const { data: profile, error } = await getUserProfile(userId)
// profile.id, profile.full_name, profile.bio, profile.role...
```

---

### `updateUserProfile(userId, updates)`
Update user profile information.

```javascript
const { data, error } = await updateUserProfile(userId, {
  full_name: 'Jane Doe',
  bio: 'Trading for 5 years',
  trading_experience: 'advanced'
})
```

**Updatable fields**:
- `full_name`
- `avatar_url`
- `bio`
- `trading_experience` ('beginner', 'intermediate', 'advanced')
- `country`

---

### `getPublicProfile(userId)`
Get minimal public profile info.

```javascript
const { data, error } = await getPublicProfile(userId)
// Shows: id, full_name, avatar_url, bio, trading_experience
```

---

## Courses

### `getAllCourses(filters)`
Get all published courses with optional filtering.

```javascript
import { getAllCourses } from '../lib/supabase'

// Get all courses
const { data: allCourses, error } = await getAllCourses()

// Filter by level
const { data: beginnerCourses } = await getAllCourses({
  level: 'beginner'
})
```

**Returns**: Array of course objects with instructor info

---

### `getCourseBySlug(slug)`
Get full course details by URL slug.

```javascript
const { data: course, error } = await getCourseBySlug('forex-basics')

// Includes:
// - course details (title, description, price...)
// - instructor profile
// - all lessons
// - all reviews
```

**Usage in Route**:
```javascript
// In pages/CourseDetail.jsx
const { slug } = useParams() // from URL
const { data: course } = await getCourseBySlug(slug)
```

---

### `enrollCourse(userId, courseId)`
Enroll a user in a course.

```javascript
const { data, error } = await enrollCourse(user.id, courseId)

if (error) toast.error('Already enrolled')
else toast.success('Enrollment successful!')
```

---

### `getUserEnrollments(userId)`
Get all courses a user is enrolled in.

```javascript
const { data: enrollments } = await getUserEnrollments(userId)

enrollments.forEach(enrollment => {
  console.log(`${enrollment.courses.title}: ${enrollment.progress_percentage}%`)
})
```

**Returns**: Array with `enrollment` and nested `courses` data

---

### `createCourseReview(userId, courseId, rating, reviewText)`
Submit a course review.

```javascript
const { data, error } = await createCourseReview(
  userId,
  courseId,
  5, // rating 1-5
  'Great course, learned a lot!'
)
```

---

## Webinars

### `getUpcomingWebinars(limit)`
Get upcoming scheduled webinars.

```javascript
const { data: webinars } = await getUpcomingWebinars(10)

webinars.forEach(w => {
  console.log(`${w.title} on ${w.scheduled_at}`)
})
```

**Returns**: Array of webinars ordered by `scheduled_at`, limited to `limit` (default 10)

---

### `getWebinarBySlug(slug)`
Get full webinar details.

```javascript
const { data: webinar } = await getWebinarBySlug('live-eur-usd')

console.log(webinar.instructor.full_name) // Instructor info
console.log(webinar.scheduled_at) // When it's happening
```

---

### `registerWebinar(userId, webinarId)`
Register for a webinar (book a ticket).

```javascript
const { data, error } = await registerWebinar(user.id, webinarId)

if (!error) toast.success('Registered! Check your email for details.')
```

---

### `getUserWebinarRegistrations(userId)`
Get all webinars a user has registered for.

```javascript
const { data: registrations } = await getUserWebinarRegistrations(userId)

registrations.forEach(reg => {
  console.log(`Registered for: ${reg.webinars.title}`)
  console.log(`Attended: ${reg.attended}`)
})
```

---

## Forum & Community

### `getForumPosts(courseId, limit)`
Get discussion posts (optionally filtered by course).

```javascript
import { getForumPosts } from '../lib/supabase'

// Get all general forum posts
const { data: posts } = await getForumPosts(null, 20)

// Get posts for a specific course
const { data: coursePosts } = await getForumPosts(courseId, 20)

posts.forEach(post => {
  console.log(`${post.title} by ${post.profiles.full_name}`)
})
```

---

### `createForumPost(userId, title, content, courseId, category)`
Create a new discussion post.

```javascript
const { data, error } = await createForumPost(
  userId,
  'How to manage risk?',
  'What is the best risk management strategy...',
  courseId, // optional
  'question' // 'general', 'question', 'discussion', 'announcement'
)
```

---

### `getForumPostReplies(postId)`
Get all replies to a forum post.

```javascript
const { data: replies } = await getForumPostReplies(postId)

replies.forEach(reply => {
  console.log(`${reply.profiles.full_name}: ${reply.content}`)
  console.log(`Likes: ${reply.likes_count}`)
})
```

---

### `replyToForumPost(userId, postId, content)`
Reply to a forum discussion.

```javascript
const { data, error } = await replyToForumPost(
  userId,
  postId,
  'Great question! Here\'s what I think...'
)
```

---

## Messaging

### `sendMessage(senderId, recipientId, content)`
Send a direct message to another user.

```javascript
const { data, error } = await sendMessage(
  currentUserId,
  instructorId,
  'I have a question about lesson 3'
)
```

---

### `getConversation(userId, otherUserId)`
Get message history with another user.

```javascript
const { data: messages } = await getConversation(userId, instructorId)

messages.forEach(msg => {
  const sender = msg.sender_id === userId ? 'You' : msg.profiles_sender.full_name
  console.log(`${sender}: ${msg.content}`)
})
```

---

## Student Statistics

### `getStudentStats(userId)`
Get a user's learning statistics.

```javascript
const { data: stats } = await getStudentStats(userId)

console.log(`Courses completed: ${stats.total_courses_completed}`)
console.log(`Total hours learned: ${stats.total_hours_learned}`)
console.log(`Current streak: ${stats.learning_streak} days`)
console.log(`Trades executed: ${stats.trading_trades_executed}`)
```

---

### `updateStudentStats(userId, updates)`
Update student statistics.

```javascript
const { data, error } = await updateStudentStats(userId, {
  total_hours_learned: 50,
  learning_streak: 10,
  trading_trades_executed: 45
})
```

---

## Real-time Subscriptions

### `subscribeToAuthChanges(callback)`
Listen for authentication state changes.

```javascript
import { subscribeToAuthChanges } from '../lib/supabase'

const subscription = subscribeToAuthChanges((event, session) => {
  if (event === 'SIGNED_IN') console.log('User logged in!')
  if (event === 'SIGNED_OUT') console.log('User logged out!')
})

// To unsubscribe later:
subscription?.unsubscribe()
```

**Events**:
- `SIGNED_IN` - User logged in
- `SIGNED_OUT` - User logged out
- `TOKEN_REFRESHED` - Session refreshed
- `USER_UPDATED` - User info changed

---

## Error Handling

All functions return `{ data, error }`. Always check for errors:

```javascript
const { data, error } = await enrollCourse(userId, courseId)

if (error) {
  console.error('Enrollment failed:', error.message)
  // Handle error - show toast, etc.
} else {
  console.log('Success!', data)
}
```

Common error messages:
- `"Duplicate key value"` - User already enrolled/registered
- `"Policy violates RLS"` - Permission denied
- `"Invalid JWT"` - Session expired
- `"23514"` - Check constraint failed (e.g., invalid rating)

---

## Tips & Best Practices

### 1. Use `.select()` to be specific
```javascript
// ❌ Fetches all fields
const { data } = await supabase.from('courses').select('*')

// ✅ Only fetch needed fields
const { data } = await getAllCourses() // Already optimized
```

### 2. Handle loading states
```javascript
const [loading, setLoading] = useState(true)

useEffect(() => {
  const fetch = async () => {
    const { data } = await getCourseBySlug(slug)
    setLoading(false)
  }
  fetch()
}, [slug])

if (loading) return <LoadingSpinner />
```

### 3. Use `useCallback` to memoize API calls
```javascript
const fetchCourse = useCallback(async (slug) => {
  return await getCourseBySlug(slug)
}, [])

useEffect(() => {
  fetchCourse(slug)
}, [slug, fetchCourse])
```

### 4. Show toast notifications for feedback
```javascript
import toast from 'react-hot-toast'

const { data, error } = await enrollCourse(userId, courseId)
if (error) {
  toast.error('Enrollment failed!')
} else {
  toast.success('Successfully enrolled!')
}
```

---

## Common Patterns

### Load Data on Component Mount
```javascript
import { useEffect, useState } from 'react'
import { getCourseBySlug } from '../lib/supabase'

export default function CourseDetail() {
  const [course, setCourse] = useState(null)
  const [loading, setLoading] = useState(true)
  const { slug } = useParams()

  useEffect(() => {
    const fetch = async () => {
      const { data, error } = await getCourseBySlug(slug)
      setCourse(data)
      setLoading(false)
    }
    fetch()
  }, [slug])

  if (loading) return <div>Loading...</div>
  return <div>{course.title}</div>
}
```

### Handle User Authentication
```javascript
import { useAuth } from '../context/AuthContext'

export default function Dashboard() {
  const { user, loading } = useAuth()

  if (loading) return <div>Loading...</div>
  if (!user) return <Navigate to="/auth" />

  return <div>Welcome, {user.email}!</div>
}
```

### Paginate Results
```javascript
const [page, setPage] = useState(0)
const itemsPerPage = 10

const { data: posts } = await getForumPosts(courseId, itemsPerPage)
// Implement pagination logic based on `page` state
```

---

That's the complete API reference! Each function is designed to make your code simple and readable.
