# Setup Guide - Forex Academy Platform

Welcome! This guide will help you set up your Forex Academy platform from scratch.

## Prerequisites

Before starting, make sure you have:
- **Node.js** 18+ ([download](https://nodejs.org/))
- **npm** or **yarn** package manager
- A **Supabase account** (free tier is fine) - [Create one](https://supabase.com)
- A **GitHub account** with your cloned repo

---

## Step 1: Supabase Project Setup (5-10 minutes)

### 1.1 Create Supabase Project

1. Go to [supabase.com](https://supabase.com) and sign in
2. Click "New Project"
3. Fill in:
   - **Name**: `forex-academy` (or your preferred name)
   - **Database Password**: Create a strong password (save it!)
   - **Region**: Choose the region closest to your users
4. Click "Create new project" and wait for it to initialize

### 1.2 Get Your Credentials

Once your project is created:

1. Go to **Settings → API**
2. Copy these values:
   - `Project URL` (under "API" section)
   - `Anon Key` (under "Project API keys")
3. **Save these securely** - you'll need them soon!

### 1.3 Initialize Database Schema

1. In your Supabase project, go to **SQL Editor**
2. Click "New Query"
3. Open the file: `supabase/migrations/001_initial_schema.sql` from this repo
4. Copy the entire SQL content
5. Paste it into the SQL Editor in Supabase
6. Click "Run" and wait for it to complete

**Success**: You should see the message "Success: No rows returned" at the bottom.

---

## Step 2: Frontend Setup (10-15 minutes)

### 2.1 Clone the Repository

```bash
# Navigate to where you want the project
cd your-projects-folder

# Clone your GitHub repo (if not already done)
git clone <your-repo-url>
cd forex-academy
```

### 2.2 Install Dependencies

```bash
cd frontend
npm install
```

This installs all required packages listed in `package.json`.

### 2.3 Configure Environment Variables

1. In the `frontend/` folder, create a `.env.local` file:

```bash
cp .env.example .env.local
```

2. Open `.env.local` and fill in your Supabase credentials:

```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here
```

Replace with the values from Step 1.2.

**Important**: 
- Never commit `.env.local` to GitHub (it's already in `.gitignore`)
- These values are safe to use (they're public/anonymous keys)

### 2.4 Start Development Server

```bash
npm run dev
```

You should see:
```
  VITE v5.0.0  ready in 123 ms

  ➜  Local:   http://localhost:5173/
  ➜  press h to show help
```

Open [http://localhost:5173](http://localhost:5173) in your browser. You should see the Forex Academy homepage!

---

## Step 3: Test the Features

### 3.1 Test Authentication

1. Click "Sign In" in the top right
2. Click "Don't have an account? Sign Up"
3. Fill in:
   - Full Name: Your Name
   - Email: your-email@example.com
   - Password: A strong password
4. Click "Create Account"

You should see: "Sign up successful! Check your email to confirm."

**Note**: With Supabase free tier, you'll get a confirmation email. Click the link to activate your account.

### 3.2 Test Database Connection

1. Sign in with your new account
2. Go to your Supabase dashboard → Table Editor
3. Check the `profiles` table - you should see your user profile!

This confirms your React app is successfully connected to your Supabase database.

### 3.3 Test Navigation

- Click "Courses" - you should see a filterable course list (currently empty)
- Click "Webinars" - you should see upcoming webinars
- Click "Community" - community forum placeholder
- Click "Dashboard" - your learning dashboard

---

## Step 4: Add Sample Data (Optional)

To test the UI with actual courses and webinars:

### 4.1 Add Sample Courses

Go to Supabase → SQL Editor → New Query:

```sql
INSERT INTO courses (title, slug, description, level, instructor_id, duration_hours, total_lessons, is_published)
VALUES
  (
    'Forex Trading Basics',
    'forex-basics',
    'Learn the fundamentals of forex trading, including currency pairs, pips, and spreads.',
    'beginner',
    (SELECT id FROM profiles LIMIT 1),
    8,
    12,
    true
  ),
  (
    'Technical Analysis Masterclass',
    'technical-analysis',
    'Master candlestick patterns, support & resistance, and trend analysis.',
    'intermediate',
    (SELECT id FROM profiles LIMIT 1),
    12,
    18,
    true
  );
```

Then check your `/courses` page - courses should appear!

### 4.2 Add Sample Webinars

```sql
INSERT INTO webinars (title, slug, description, topic, instructor_id, scheduled_at, duration_minutes, is_free)
VALUES
  (
    'Live Trading Session: EUR/USD Analysis',
    'live-eur-usd',
    'Join us for a live analysis of the EUR/USD pair with real-time trading insights.',
    'price-action',
    (SELECT id FROM profiles LIMIT 1),
    NOW() + INTERVAL '3 days',
    60,
    true
  );
```

Check `/webinars` page - your webinar should appear!

---

## Step 5: Project Structure Overview

```
forex-academy/
├── frontend/                           # React application
│   ├── src/
│   │   ├── components/                # Reusable components (Header, Footer)
│   │   ├── pages/                     # Page components (Home, Courses, etc.)
│   │   ├── context/                   # State management (AuthContext)
│   │   ├── lib/                       # Utilities (Supabase client)
│   │   ├── styles/                    # Global CSS (globals.css)
│   │   ├── App.jsx                    # Main app component with routing
│   │   └── main.jsx                   # React entry point
│   ├── package.json                   # Dependencies
│   ├── vite.config.js                 # Vite config
│   ├── tailwind.config.js             # Tailwind CSS config
│   ├── .env.example                   # Environment variables template
│   └── .env.local                     # Your actual credentials (don't commit!)
│
└── supabase/
    └── migrations/
        └── 001_initial_schema.sql    # Database tables and setup
```

---

## Step 6: Key Files Explained

### `src/lib/supabase.js`
Contains all functions that communicate with your Supabase database:
- `signUp()`, `signIn()`, `signOut()` - Authentication
- `getAllCourses()`, `getCourseBySlug()`, `enrollCourse()` - Course operations
- `getUpcomingWebinars()`, `registerWebinar()` - Webinar operations
- `getForumPosts()`, `createForumPost()` - Community features

**To use these functions in a component:**
```javascript
import { getAllCourses } from '../lib/supabase'

const { data, error } = await getAllCourses()
```

### `src/context/AuthContext.jsx`
Manages user authentication state globally:
```javascript
import { useAuth } from '../context/AuthContext'

function MyComponent() {
  const { user, profile, loading } = useAuth()
  // user: Supabase auth user object
  // profile: User's profile from database
  // loading: Is auth still loading?
}
```

### `src/App.jsx`
Main routing setup using React Router:
- `/` → Home page
- `/courses` → Course catalog
- `/courses/:slug` → Course details
- `/webinars` → Upcoming webinars
- `/webinars/:slug` → Webinar details
- `/dashboard` → Student dashboard
- `/community` → Community forums
- `/auth` → Sign in/sign up

---

## Step 7: Development Workflow

### Running the Dev Server

```bash
cd frontend
npm run dev
```

The app will:
- Reload automatically when you save files
- Show errors in the browser console
- Connect to your Supabase project in real-time

### Building for Production

```bash
npm run build
```

This creates an optimized version in the `dist/` folder, ready to deploy.

---

## Step 8: Common Issues & Solutions

### Issue: "Missing Supabase URL or Anon Key"

**Cause**: `.env.local` file is missing or incomplete

**Solution**:
1. Create `.env.local` in the `frontend/` folder
2. Copy values from `.env.example`
3. Fill in your actual Supabase credentials
4. Restart the dev server

### Issue: "Connection refused" when signing up

**Cause**: Supabase database hasn't been initialized

**Solution**:
1. Go to Supabase Dashboard → SQL Editor
2. Run the SQL from `supabase/migrations/001_initial_schema.sql`
3. Wait for it to complete
4. Try signing up again

### Issue: Courses/Webinars don't appear

**Cause**: No sample data in the database

**Solution**:
1. Follow Step 4 to add sample data
2. Or manually add data through Supabase Table Editor
3. Refresh the page

### Issue: npm install fails

**Cause**: Node.js version is too old

**Solution**:
1. Check your Node version: `node --version`
2. Update to Node 18+: https://nodejs.org/
3. Run `npm install` again

---

## Next Steps

1. **Customize branding**: Edit colors in `tailwind.config.js`
2. **Add your logo**: Replace the "F" icon in Header.jsx
3. **Create courses**: Add courses through Supabase Table Editor
4. **Customize pages**: Edit components in `src/components/` and pages in `src/pages/`
5. **Deploy**: When ready, deploy to Vercel (frontend) and Supabase Cloud (database)

---

## Deployment (Optional)

### Deploy Frontend to Vercel

1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Click "Import Project"
4. Select your repo
5. Set environment variables:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
6. Click "Deploy"

Your site will be live in minutes!

### Database is Already on Supabase Cloud

Your Supabase database is already hosted and accessible worldwide. No additional setup needed!

---

## Need Help?

- Check error messages in the browser console (F12)
- Review Supabase documentation: https://supabase.com/docs
- Ask in your development community or forums

---

## Success Checklist

- ✅ Node.js 18+ installed
- ✅ Supabase project created
- ✅ Database schema initialized (SQL migration run)
- ✅ `.env.local` created with credentials
- ✅ `npm install` completed
- ✅ Dev server running (`npm run dev`)
- ✅ Can see homepage at localhost:5173
- ✅ Can sign up and see profile in database
- ✅ Can navigate between pages

Once you've completed all of these, you're ready to start building out your academy!

Happy coding! 🚀
