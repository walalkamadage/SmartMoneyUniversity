# Database Schema Documentation

Complete reference for the Forex Academy database structure.

## Tables Overview

### 👥 User Management

#### `profiles`
Stores extended user information (extends Supabase Auth).

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID | Foreign key to auth.users, Primary key |
| `email` | VARCHAR | User's email, unique |
| `full_name` | VARCHAR | User's display name |
| `avatar_url` | TEXT | Profile picture URL |
| `bio` | TEXT | User biography |
| `role` | VARCHAR | 'student', 'instructor', or 'admin' |
| `trading_experience` | VARCHAR | 'beginner', 'intermediate', 'advanced' |
| `country` | VARCHAR | User's country |
| `created_at` | TIMESTAMP | Account creation date |
| `updated_at` | TIMESTAMP | Last profile update |

**Relationships**:
- Extends `auth.users` (one-to-one)
- Referenced by: enrollments, lessons, webinars, forum_posts, messages

---

#### `student_stats`
Tracks learning progress and engagement metrics.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID | Primary key |
| `user_id` | UUID | Foreign key to profiles (unique) |
| `total_courses_enrolled` | INT | Number of courses joined |
| `total_courses_completed` | INT | Number of completed courses |
| `total_hours_learned` | DECIMAL | Total learning hours |
| `learning_streak` | INT | Consecutive days of activity |
| `trading_trades_executed` | INT | Trades made by user |
| `created_at` | TIMESTAMP | Record creation |
| `updated_at` | TIMESTAMP | Last update |

---

### 📚 Course Management

#### `courses`
Course information and metadata.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID | Primary key |
| `title` | VARCHAR | Course name |
| `slug` | VARCHAR | URL-friendly identifier (unique) |
| `description` | TEXT | Course overview |
| `thumbnail_url` | TEXT | Course image URL |
| `level` | VARCHAR | 'beginner', 'intermediate', 'advanced' |
| `instructor_id` | UUID | Foreign key to profiles |
| `price` | DECIMAL | Course cost (0 = free) |
| `duration_hours` | DECIMAL | Total course duration |
| `total_lessons` | INT | Number of lessons |
| `rating` | DECIMAL | Average rating (0-5) |
| `total_ratings` | INT | Number of ratings |
| `student_count` | INT | Number of enrollments |
| `is_published` | BOOLEAN | Visible to students? |
| `created_at` | TIMESTAMP | Creation date |
| `updated_at` | TIMESTAMP | Last update |

**Example Query**:
```javascript
const { data } = await getAllCourses({ level: 'beginner' })
```

---

#### `lessons`
Individual lessons within courses.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID | Primary key |
| `course_id` | UUID | Foreign key to courses |
| `title` | VARCHAR | Lesson name |
| `slug` | VARCHAR | URL identifier |
| `description` | TEXT | Lesson overview |
| `video_url` | TEXT | Video file URL |
| `content` | TEXT | Lesson text content |
| `lesson_order` | INT | Position in course (1, 2, 3...) |
| `duration_minutes` | INT | Video length |
| `is_free_preview` | BOOLEAN | Free to watch without enrollment? |
| `created_at` | TIMESTAMP | Creation date |
| `updated_at` | TIMESTAMP | Last update |

**Constraint**: `UNIQUE(course_id, slug)` - each course has unique lesson slugs

---

#### `enrollments`
Student enrollment records.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID | Primary key |
| `user_id` | UUID | Foreign key to profiles |
| `course_id` | UUID | Foreign key to courses |
| `progress_percentage` | INT | Completion % (0-100) |
| `status` | VARCHAR | 'enrolled', 'in-progress', 'completed' |
| `completed_lessons` | INT | Lessons finished |
| `enrolled_at` | TIMESTAMP | Join date |
| `completed_at` | TIMESTAMP | Completion date (null if not done) |

**Constraint**: `UNIQUE(user_id, course_id)` - one enrollment per user per course

**Example Query**:
```javascript
const { data } = await getUserEnrollments(userId)
```

---

#### `lesson_progress`
Tracks individual lesson completion.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID | Primary key |
| `user_id` | UUID | Foreign key to profiles |
| `lesson_id` | UUID | Foreign key to lessons |
| `is_completed` | BOOLEAN | Finished? |
| `watched_duration_minutes` | INT | Time watched |
| `completed_at` | TIMESTAMP | Completion date |

---

#### `course_reviews`
Student ratings and reviews.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID | Primary key |
| `course_id` | UUID | Foreign key to courses |
| `user_id` | UUID | Foreign key to profiles |
| `rating` | INT | 1-5 stars |
| `review_text` | TEXT | Review content |
| `created_at` | TIMESTAMP | Review date |
| `updated_at` | TIMESTAMP | Last edit |

**Constraint**: `UNIQUE(course_id, user_id)` - one review per user per course

---

### 🎥 Webinar Management

#### `webinars`
Live webinar sessions.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID | Primary key |
| `title` | VARCHAR | Webinar title |
| `slug` | VARCHAR | URL identifier (unique) |
| `description` | TEXT | Webinar details |
| `thumbnail_url` | TEXT | Webinar image |
| `topic` | VARCHAR | Category (price-action, risk-management, etc.) |
| `instructor_id` | UUID | Foreign key to profiles |
| `scheduled_at` | TIMESTAMP | Start time |
| `duration_minutes` | INT | Expected length |
| `max_attendees` | INT | Capacity limit |
| `status` | VARCHAR | 'scheduled', 'live', 'completed' |
| `recording_url` | TEXT | Video replay link |
| `is_free` | BOOLEAN | Free to attend? |
| `attendee_count` | INT | Current registrations |
| `created_at` | TIMESTAMP | Creation date |
| `updated_at` | TIMESTAMP | Last update |

**Example Query**:
```javascript
const { data } = await getUpcomingWebinars(10)
```

---

#### `webinar_registrations`
Student webinar registrations (tickets).

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID | Primary key |
| `webinar_id` | UUID | Foreign key to webinars |
| `user_id` | UUID | Foreign key to profiles |
| `registered_at` | TIMESTAMP | Registration date |
| `attended` | BOOLEAN | Did they join? |
| `attended_at` | TIMESTAMP | Join time |

**Constraint**: `UNIQUE(webinar_id, user_id)` - one registration per user per webinar

**Example Query**:
```javascript
const { data } = await registerWebinar(userId, webinarId)
```

---

### 💬 Community & Forums

#### `forum_posts`
Discussion thread starters.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID | Primary key |
| `course_id` | UUID | Which course (nullable for general) |
| `user_id` | UUID | Foreign key to profiles |
| `title` | VARCHAR | Post title |
| `content` | TEXT | Post body |
| `category` | VARCHAR | 'general', 'question', 'discussion', 'announcement' |
| `is_pinned` | BOOLEAN | Stay at top? |
| `view_count` | INT | Number of views |
| `reply_count` | INT | Number of responses |
| `created_at` | TIMESTAMP | Creation date |
| `updated_at` | TIMESTAMP | Last edit |

**Example Query**:
```javascript
const { data } = await getForumPosts(courseId)
```

---

#### `forum_replies`
Comments on forum posts.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID | Primary key |
| `post_id` | UUID | Foreign key to forum_posts |
| `user_id` | UUID | Foreign key to profiles |
| `content` | TEXT | Reply content |
| `likes_count` | INT | Upvotes |
| `is_answer` | BOOLEAN | Marked as correct answer? |
| `created_at` | TIMESTAMP | Creation date |
| `updated_at` | TIMESTAMP | Last edit |

---

#### `leaderboard`
Monthly activity rankings.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID | Primary key |
| `user_id` | UUID | Foreign key to profiles |
| `month` | VARCHAR | Format: YYYY-MM |
| `activity_score` | INT | Total points |
| `posts_created` | INT | Posts made |
| `posts_liked` | INT | Posts upvoted |
| `rank` | INT | Position (1 = top) |

**Constraint**: `UNIQUE(user_id, month)` - one rank entry per user per month

---

### 📧 Messaging

#### `messages`
Direct messages between users.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID | Primary key |
| `sender_id` | UUID | Foreign key to profiles |
| `recipient_id` | UUID | Foreign key to profiles |
| `content` | TEXT | Message body |
| `is_read` | BOOLEAN | Has recipient seen it? |
| `read_at` | TIMESTAMP | When they read it |
| `created_at` | TIMESTAMP | Sent time |

**Example Query**:
```javascript
const { data } = await getConversation(userId, otherUserId)
```

---

## Relationships Diagram

```
auth.users (Supabase)
    ↓
profiles ←──────────┐
    ↑               │
    ├─ student_stats
    ├─ enrollments ──→ courses
    ├─ lesson_progress ──→ lessons ──→ courses
    ├─ course_reviews ──→ courses
    ├─ webinar_registrations ──→ webinars
    ├─ forum_posts ──→ courses (optional)
    ├─ forum_replies ──→ forum_posts
    ├─ messages ──→ messages (self-ref)
    └─ leaderboard
```

---

## Row Level Security (RLS) Policies

All tables have RLS enabled. Key policies:

### Profiles
- **SELECT**: Public - everyone can view profiles
- **UPDATE**: Users can only update their own profile

### Enrollments
- **SELECT**: Users can only see their own enrollments
- **INSERT**: Users can only create enrollments for themselves

### Lessons
- **SELECT**: Free preview lessons visible to all; paid lessons only for enrolled students

### Messages
- **SELECT**: Users can only see messages they sent or received

---

## Indexes for Performance

Indexes are created on frequently queried columns:

```sql
CREATE INDEX idx_profiles_role ON profiles(role);
CREATE INDEX idx_courses_level ON courses(level);
CREATE INDEX idx_enrollments_user_id ON enrollments(user_id);
CREATE INDEX idx_webinars_status ON webinars(status);
-- ... and more
```

These speed up queries like:
- "Get all courses at beginner level"
- "Get user's enrollments"
- "Get scheduled webinars"

---

## Adding New Data

### Insert a Course

```javascript
const { data, error } = await supabase
  .from('courses')
  .insert({
    title: 'My New Course',
    slug: 'my-new-course',
    description: 'Learn awesome stuff',
    level: 'intermediate',
    instructor_id: currentUserId,
    duration_hours: 10,
    total_lessons: 15,
    is_published: false
  })
```

### Insert a Lesson

```javascript
const { data, error } = await supabase
  .from('lessons')
  .insert({
    course_id: courseId,
    title: 'Lesson 1: Intro',
    slug: 'intro',
    lesson_order: 1,
    duration_minutes: 30,
    is_free_preview: true
  })
```

---

## Tips & Best Practices

1. **Always use slugs**: Instead of querying by ID, use readable slugs (e.g., `/courses/forex-basics`)

2. **Filter on client side**: Use Supabase `.select().eq().order()` to filter at database level, not in JavaScript

3. **Lazy load**: Only fetch needed fields with `.select('field1, field2')`

4. **Watch for N+1 queries**: Join related tables in a single query when possible

5. **Use timestamps**: Always check `created_at` and `updated_at` for sorting

---

## Migration & Scaling

To add new tables or modify schema:

1. Create a new SQL migration file: `002_add_feature.sql`
2. Test it locally in Supabase
3. Run it in production
4. Update this documentation

---

That's it! You now have a robust, scalable database for your forex academy platform.
