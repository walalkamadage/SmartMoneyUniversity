# Forex Trading Academy Platform

A modern, community-driven online academy for forex trading courses and live webinars. Built with React, Supabase, and Tailwind CSS.

## 🎯 Features

### Student Experience
- **Course Catalog** – Browse and enroll in structured forex trading courses
- **Live Webinars** – Register for live trading sessions with countdown timers
- **Student Dashboard** – Track enrolled courses, booked webinars, and learning progress
- **Community Hub** – Discussion forums, peer Q&A, student leaderboard
- **User Profiles** – Authentication, learning stats, saved courses

### Instructor Tools
- **Course Management** – Create and manage course content
- **Webinar Scheduling** – Schedule live sessions and manage attendance
- **Student Analytics** – View enrollment, engagement, and completion rates
- **Forum Moderation** – Manage discussions and community posts

### Admin Panel
- **Full Content Management** – Courses, webinars, users, content
- **Community Moderation** – Manage forums and discussions
- **Analytics Dashboard** – Real-time engagement and enrollment metrics
- **Email Campaigns** – Send announcements to user cohorts

---

## 🛠️ Tech Stack

- **Frontend**: React 18 + Vite
- **Styling**: Tailwind CSS
- **Backend/Database**: Supabase (PostgreSQL)
- **Authentication**: Supabase Auth
- **Real-time**: Supabase Realtime
- **Hosting**: Vercel (frontend) + Supabase Cloud (backend)

---

## 📁 Project Structure

```
forex-academy/
├── frontend/                      # React application
│   ├── src/
│   │   ├── components/           # Reusable UI components
│   │   │   ├── Header.jsx
│   │   │   ├── Footer.jsx
│   │   │   ├── CourseCard.jsx
│   │   │   ├── WebinarCard.jsx
│   │   │   └── ...
│   │   ├── pages/                # Page components
│   │   │   ├── Home.jsx
│   │   │   ├── Courses.jsx
│   │   │   ├── CourseDetail.jsx
│   │   │   ├── Webinars.jsx
│   │   │   ├── WebinarDetail.jsx
│   │   │   ├── Dashboard.jsx
│   │   │   ├── Community.jsx
│   │   │   ├── Auth/
│   │   │   └── Admin/
│   │   ├── context/              # State management (Auth, User)
│   │   ├── hooks/                # Custom React hooks
│   │   ├── lib/                  # Utilities (supabase client, helpers)
│   │   ├── styles/               # Global styles & Tailwind config
│   │   ├── App.jsx
│   │   └── main.jsx
│   ├── package.json
│   ├── vite.config.js
│   ├── tailwind.config.js
│   └── .env.example
│
├── supabase/                      # Supabase configuration
│   ├── migrations/               # SQL migration files
│   │   ├── 001_initial_schema.sql
│   │   └── ...
│   ├── functions/                # Edge Functions (optional)
│   └── README.md
│
├── docs/                         # Documentation
│   ├── SETUP.md                 # Installation & environment setup
│   ├── DATABASE.md              # Database schema documentation
│   ├── API.md                   # API endpoints & usage
│   └── FEATURES.md              # Feature descriptions
│
├── .env.example                 # Example environment variables
├── .gitignore
└── package.json                 # Monorepo root (optional)
```

---

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- npm or yarn
- Supabase account (free tier available at [supabase.com](https://supabase.com))

### 1. Clone & Install

```bash
git clone <your-repo-url>
cd forex-academy
cd frontend
npm install
```

### 2. Set Up Supabase

1. Create a new Supabase project at [supabase.com](https://supabase.com)
2. Copy your project URL and API key
3. Create `.env.local` in the `frontend/` directory:

```env
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

### 3. Initialize Database

Run the SQL migrations in your Supabase dashboard (SQL Editor):

```bash
# Copy contents from supabase/migrations/001_initial_schema.sql
# Paste in Supabase SQL Editor and execute
```

### 4. Run Development Server

```bash
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

---

## 📚 Documentation

- [Setup Guide](docs/SETUP.md) – Detailed installation steps
- [Database Schema](docs/DATABASE.md) – Table structures and relationships
- [API Reference](docs/API.md) – Available endpoints and hooks
- [Features](docs/FEATURES.md) – Detailed feature descriptions

---

## 📦 Environment Variables

See `.env.example` for a complete list. Key variables:

```env
VITE_SUPABASE_URL=          # Your Supabase project URL
VITE_SUPABASE_ANON_KEY=     # Your Supabase anonymous API key
```

---

## 🔐 Authentication

The app uses Supabase Auth for user management:

- Email/password signup and login
- Password reset via email
- Role-based access control (student, instructor, admin)
- Session management

---

## 💬 Community Features

- **Forums** – Per-course discussions and general trading topics
- **Leaderboard** – Rank students by activity or performance
- **Peer Q&A** – Students help each other with questions
- **Instructor Support** – Direct messaging with course instructors

---

## 🎨 Design Philosophy

The platform emphasizes clarity, engagement, and professional aesthetics:

- Clean, modern UI with professional branding
- Intuitive navigation and user flows
- Community-driven design (highlight social features)
- Mobile-responsive throughout
- Dark/light mode support

---

## 🔮 Future Enhancements

- Payment integration (Stripe/PayPal)
- Video streaming optimization
- AI-powered trading insights
- Mobile app (React Native)
- Advanced analytics dashboard
- Certification system
- 1-on-1 mentorship bookings

---

## 📄 License

MIT License – see LICENSE file for details.

---

## 🤝 Support

For questions or issues, please open a GitHub issue or contact the development team.

Happy trading! 📈
