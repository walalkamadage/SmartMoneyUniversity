/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html","./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        navy:  { DEFAULT: '#0A0F1E', mid: '#111827', light: '#1E293B' },
        gold:  { DEFAULT: '#D4A843', light: '#F0C96A', dark: '#A07830' },
        slate: { DEFAULT: '#64748B' },
      },
      fontFamily: {
        display: ['Syne', 'sans-serif'],
        body:    ['DM Sans', 'sans-serif'],
      },
      boxShadow: {
        gold:    '0 0 24px rgba(212,168,67,0.35)',
        card:    '0 4px 24px rgba(0,0,0,0.4)',
        heavy:   '0 20px 60px rgba(0,0,0,0.6)',
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'gold-shine': 'linear-gradient(135deg, #D4A843, #F0C96A)',
      },
    },
  },
  plugins: [],
}
