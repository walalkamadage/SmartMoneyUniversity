import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { AuthProvider } from './context/AuthContext'
import './styles/globals.css'

import Header from './components/Header'
import Footer from './components/Footer'

import Home          from './pages/Home'
import Courses       from './pages/Courses'
import CourseDetail  from './pages/CourseDetail'
import Webinars      from './pages/Webinars'
import WebinarDetail from './pages/WebinarDetail'
import Community     from './pages/Community'
import Dashboard     from './pages/Dashboard'
import AuthPage      from './pages/Auth/AuthPage'
import NotFound      from './pages/NotFound'

export default function App() {
  return (
    <Router>
      <AuthProvider>
        <div className="min-h-screen bg-navy flex flex-col">
          <Header />
          <main className="flex-1">
            <Routes>
              <Route path="/"               element={<Home />} />
              <Route path="/courses"        element={<Courses />} />
              <Route path="/courses/:slug"  element={<CourseDetail />} />
              <Route path="/webinars"       element={<Webinars />} />
              <Route path="/webinars/:slug" element={<WebinarDetail />} />
              <Route path="/community"      element={<Community />} />
              <Route path="/dashboard"      element={<Dashboard />} />
              <Route path="/auth"           element={<AuthPage />} />
              <Route path="/404"            element={<NotFound />} />
              <Route path="*"              element={<Navigate to="/404" replace />} />
            </Routes>
          </main>
          <Footer />
        </div>
        <Toaster
          position="top-right"
          toastOptions={{
            style: { background:'#111827', color:'#E2E8F0', border:'1px solid rgba(212,168,67,0.25)' },
            success: { iconTheme:{ primary:'#D4A843', secondary:'#0A0F1E' } },
          }}
        />
      </AuthProvider>
    </Router>
  )
}
