import { Link } from 'react-router-dom'
import { TrendingUp, Twitter, Linkedin, Youtube, Mail } from 'lucide-react'

export default function Footer() {
  const year = new Date().getFullYear()

  const links = {
    Learn:   [{l:'Courses',h:'/courses'},{l:'Webinars',h:'/webinars'},{l:'Community',h:'/community'}],
    Company: [{l:'About',h:'#'},{l:'Blog',h:'#'},{l:'Contact',h:'#'}],
    Legal:   [{l:'Privacy',h:'#'},{l:'Terms',h:'#'},{l:'Risk Disclaimer',h:'#'}],
  }

  return (
    <footer className="border-t border-gold mt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-10">
          {/* Brand */}
          <div className="col-span-2">
            <Link to="/" className="flex items-center gap-2.5 mb-4">
              <div className="w-9 h-9 rounded-lg bg-gold-shine flex items-center justify-center shadow-gold">
                <TrendingUp size={18} className="text-navy" strokeWidth={2.5} />
              </div>
              <span className="font-display font-bold text-lg text-white">
                Forex<span className="text-gold">Academy</span>
              </span>
            </Link>
            <p className="text-sm text-slate-400 max-w-xs leading-relaxed">
              Professional forex trading education — from beginner foundations to advanced institutional strategies.
            </p>
            <div className="flex gap-3 mt-5">
              {[Twitter, Linkedin, Youtube, Mail].map((Icon, i) => (
                <a key={i} href="#"
                  className="w-9 h-9 glass rounded-lg flex items-center justify-center text-slate-400 hover:text-gold hover:border-gold transition-colors">
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>

          {/* Link columns */}
          {Object.entries(links).map(([cat, items]) => (
            <div key={cat}>
              <p className="text-xs font-display font-semibold text-gold uppercase tracking-widest mb-4">{cat}</p>
              <ul className="space-y-2.5">
                {items.map(item => (
                  <li key={item.l}>
                    <Link to={item.h} className="text-sm text-slate-400 hover:text-white transition-colors">
                      {item.l}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="divider-gold" />

        <div className="flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-slate-500">
          <p>© {year} ForexAcademy. All rights reserved.</p>
          <p>⚠️ Trading involves significant risk. Past performance is not indicative of future results.</p>
        </div>
      </div>
    </footer>
  )
}
