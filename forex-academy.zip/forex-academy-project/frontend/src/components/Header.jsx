import { useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { Menu, X, LogOut, LayoutDashboard, TrendingUp, ChevronDown } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { signOut } from '../lib/supabase'
import toast from 'react-hot-toast'

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [dropOpen, setDropOpen] = useState(false)
  const { user, profile } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()

  const navLinks = [
    { label: 'Courses',  href: '/courses' },
    { label: 'Webinars', href: '/webinars' },
    { label: 'Community',href: '/community' },
  ]

  const active = (href) => location.pathname.startsWith(href)
    ? 'text-gold font-semibold' : 'text-slate-300 hover:text-white'

  const handleSignOut = async () => {
    await signOut()
    toast.success('Signed out')
    navigate('/')
    setDropOpen(false)
    setMenuOpen(false)
  }

  const initials = profile?.full_name
    ? profile.full_name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0,2)
    : user?.email?.[0]?.toUpperCase() || 'U'

  return (
    <header className="sticky top-0 z-50 glass border-b border-gold">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">

          {/* Logo */}
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="w-8 h-8 rounded-lg bg-gold-shine flex items-center justify-center shadow-gold">
              <TrendingUp size={18} className="text-navy" strokeWidth={2.5} />
            </div>
            <span className="font-display font-bold text-lg text-white tracking-tight">
              Forex<span className="text-gold">Academy</span>
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map(l => (
              <Link key={l.href} to={l.href}
                className={`text-sm transition-colors ${active(l.href)}`}>
                {l.label}
              </Link>
            ))}
          </nav>

          {/* Right side */}
          <div className="flex items-center gap-3">
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setDropOpen(p => !p)}
                  className="flex items-center gap-2 py-1.5 px-2.5 rounded-lg hover:bg-white/5 transition-colors"
                >
                  <div className="w-8 h-8 rounded-full bg-gold-shine flex items-center justify-center text-navy font-bold text-sm font-display">
                    {initials}
                  </div>
                  <span className="hidden sm:block text-sm text-slate-300">
                    {profile?.full_name?.split(' ')[0] || 'Account'}
                  </span>
                  <ChevronDown size={14} className={`text-slate-400 transition-transform ${dropOpen ? 'rotate-180' : ''}`} />
                </button>

                {dropOpen && (
                  <div className="absolute right-0 mt-2 w-52 glass rounded-xl shadow-heavy overflow-hidden">
                    <div className="px-4 py-3 border-b border-gold">
                      <p className="text-sm font-semibold text-white">{profile?.full_name || 'Trader'}</p>
                      <p className="text-xs text-slate-400 truncate">{user.email}</p>
                    </div>
                    <Link to="/dashboard" onClick={() => setDropOpen(false)}
                      className="flex items-center gap-2.5 px-4 py-3 text-sm text-slate-300 hover:bg-white/5 hover:text-white transition-colors">
                      <LayoutDashboard size={15} />
                      Dashboard
                    </Link>
                    <button onClick={handleSignOut}
                      className="flex items-center gap-2.5 w-full px-4 py-3 text-sm text-red-400 hover:bg-red-500/10 transition-colors border-t border-gold">
                      <LogOut size={15} />
                      Sign Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="hidden sm:flex items-center gap-2">
                <Link to="/auth" className="btn-ghost text-sm">Sign In</Link>
                <Link to="/auth?tab=signup" className="btn-gold text-sm py-2 px-4">
                  Get Started
                </Link>
              </div>
            )}

            {/* Mobile toggle */}
            <button onClick={() => setMenuOpen(p => !p)}
              className="md:hidden p-2 rounded-lg hover:bg-white/5 text-slate-300">
              {menuOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {menuOpen && (
          <div className="md:hidden py-4 border-t border-gold space-y-1">
            {navLinks.map(l => (
              <Link key={l.href} to={l.href} onClick={() => setMenuOpen(false)}
                className={`block px-3 py-2.5 rounded-lg text-sm transition-colors ${active(l.href)}`}>
                {l.label}
              </Link>
            ))}
            {user ? (
              <>
                <Link to="/dashboard" onClick={() => setMenuOpen(false)}
                  className="block px-3 py-2.5 rounded-lg text-sm text-slate-300 hover:text-white">
                  Dashboard
                </Link>
                <button onClick={handleSignOut}
                  className="block w-full text-left px-3 py-2.5 rounded-lg text-sm text-red-400">
                  Sign Out
                </button>
              </>
            ) : (
              <div className="pt-2 flex flex-col gap-2">
                <Link to="/auth" onClick={() => setMenuOpen(false)} className="btn-outline text-sm justify-center">Sign In</Link>
                <Link to="/auth?tab=signup" onClick={() => setMenuOpen(false)} className="btn-gold text-sm justify-center">Get Started</Link>
              </div>
            )}
          </div>
        )}
      </div>
    </header>
  )
}
