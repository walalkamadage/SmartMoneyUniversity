import { useState, useEffect } from 'react'
import { Link, Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { getUserEnrollments, getUserWebinarRegistrations, getStudentStats } from '../lib/supabase'
import { BookOpen, Video, Clock, TrendingUp, Flame, BarChart2, Calendar, ChevronRight, Award } from 'lucide-react'
import { format } from 'date-fns'

function StatCard({ icon: Icon, label, value, sub }) {
  return (
    <div className="card p-5 flex items-start gap-4">
      <div className="w-11 h-11 rounded-xl bg-gold/10 border border-gold/20 flex items-center justify-center shrink-0">
        <Icon size={20} className="text-gold" />
      </div>
      <div>
        <p className="text-2xl font-display font-bold text-white">{value}</p>
        <p className="text-sm text-slate-400">{label}</p>
        {sub && <p className="text-xs text-slate-600 mt-0.5">{sub}</p>}
      </div>
    </div>
  )
}

// Placeholder data shown for demo
const PLACEHOLDER_ENROLLMENTS = [
  { id:'e1', course_id:'c1', progress_percentage:72, status:'in-progress', completed_lessons:10, courses:{ id:'c1', title:'Price Action Mastery', slug:'price-action-system', thumbnail_url:null, total_lessons:14 } },
  { id:'e2', course_id:'c2', progress_percentage:100, status:'completed', completed_lessons:14, courses:{ id:'c2', title:'Forex Foundations', slug:'forex-foundations', thumbnail_url:null, total_lessons:14 } },
  { id:'e3', course_id:'c3', progress_percentage:18, status:'in-progress', completed_lessons:4, courses:{ id:'c3', title:'ICT Concepts & Smart Money', slug:'ict-smart-money', thumbnail_url:null, total_lessons:22 } },
]

const PLACEHOLDER_WEBINARS = [
  { id:'r1', webinar_id:'w1', registered_at: new Date().toISOString(), attended:false, webinars:{ id:'w1', title:'London Session Live Trade', slug:'london-session-analysis', scheduled_at: new Date(Date.now()+1.5*86400000).toISOString(), status:'scheduled' } },
  { id:'r2', webinar_id:'w2', registered_at: new Date().toISOString(), attended:true, webinars:{ id:'w2', title:'Risk Management Masterclass', slug:'risk-management-masterclass', scheduled_at: new Date(Date.now()-3*86400000).toISOString(), status:'completed' } },
]

const PLACEHOLDER_STATS = { total_courses_enrolled:3, total_courses_completed:1, total_hours_learned:18.5, learning_streak:6, trading_trades_executed:42 }

export default function Dashboard() {
  const { user, profile, loading: authLoading } = useAuth()
  const [enrollments, setEnrollments] = useState([])
  const [webinars, setWebinars] = useState([])
  const [stats, setStats] = useState(null)
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState('courses')

  useEffect(() => {
    if (!user) return
    const fetch = async () => {
      const [{ data: enr }, { data: web }, { data: stat }] = await Promise.all([
        getUserEnrollments(user.id),
        getUserWebinarRegistrations(user.id),
        getStudentStats(user.id),
      ])
      setEnrollments(enr?.length ? enr : PLACEHOLDER_ENROLLMENTS)
      setWebinars(web?.length ? web : PLACEHOLDER_WEBINARS)
      setStats(stat || PLACEHOLDER_STATS)
      setLoading(false)
    }
    fetch()
  }, [user])

  if (authLoading) return null
  if (!user) return <Navigate to="/auth" replace />

  const initials = profile?.full_name
    ? profile.full_name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0,2)
    : 'U'

  return (
    <div className="bg-navy min-h-screen">
      <div className="max-w-6xl mx-auto px-4 py-10">
        {/* Greeting */}
        <div className="flex items-center gap-5 mb-10 fade-up">
          <div className="w-14 h-14 rounded-2xl bg-gold-shine flex items-center justify-center text-navy text-xl font-bold font-display shadow-gold">
            {initials}
          </div>
          <div>
            <p className="text-slate-400 text-sm">Welcome back,</p>
            <h1 className="text-3xl font-display font-bold text-white">
              {profile?.full_name?.split(' ')[0] || 'Trader'} 👋
            </h1>
          </div>
          {stats?.learning_streak > 0 && (
            <div className="ml-auto flex items-center gap-2 glass px-4 py-2.5 rounded-xl">
              <Flame size={18} className="text-orange-400" />
              <div>
                <p className="text-xs text-slate-500 leading-none">Streak</p>
                <p className="font-display font-bold text-white text-sm">{stats.learning_streak} days</p>
              </div>
            </div>
          )}
        </div>

        {/* Stats */}
        {stats && (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10 fade-up fade-up-delay-1">
            <StatCard icon={BookOpen} label="Courses enrolled"   value={stats.total_courses_enrolled} />
            <StatCard icon={Award}    label="Courses completed"  value={stats.total_courses_completed} />
            <StatCard icon={Clock}    label="Hours learned"      value={`${stats.total_hours_learned}h`} />
            <StatCard icon={BarChart2} label="Trades tracked"    value={stats.trading_trades_executed} />
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-1 glass w-fit rounded-xl p-1 mb-8 fade-up fade-up-delay-2">
          {['courses','webinars'].map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`px-5 py-2 rounded-lg text-sm font-display font-semibold capitalize transition-all ${
                tab === t ? 'bg-gold-shine text-navy shadow-gold' : 'text-slate-400 hover:text-white'
              }`}>
              {t === 'courses' ? <><BookOpen size={14} className="inline mr-1.5" />Courses</> : <><Video size={14} className="inline mr-1.5" />Webinars</>}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="grid sm:grid-cols-2 gap-4">
            {Array.from({length:3}).map((_,i) => <div key={i} className="card h-32 animate-pulse bg-white/5" />)}
          </div>
        ) : tab === 'courses' ? (
          <div className="space-y-4 fade-up">
            {enrollments.length === 0 ? (
              <div className="card p-10 text-center">
                <BookOpen size={40} className="mx-auto text-slate-600 mb-4" />
                <p className="text-slate-400 mb-6">You haven't enrolled in any courses yet.</p>
                <Link to="/courses" className="btn-gold text-sm">Browse Courses</Link>
              </div>
            ) : enrollments.map(e => (
              <Link key={e.id} to={`/courses/${e.courses.slug}`}
                className="card p-5 flex items-center gap-5 group">
                <div className="w-14 h-14 rounded-xl bg-gold/10 border border-gold/20 flex items-center justify-center shrink-0">
                  <BarChart2 size={22} className="text-gold/60" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-display font-semibold text-white group-hover:text-gold transition-colors truncate">
                    {e.courses.title}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    {e.completed_lessons} / {e.courses.total_lessons} lessons
                  </p>
                  <div className="progress-bar mt-2">
                    <div className="progress-fill" style={{ width: `${e.progress_percentage}%` }} />
                  </div>
                </div>
                <div className="shrink-0 text-right">
                  <p className="text-gold font-display font-bold text-lg">{e.progress_percentage}%</p>
                  <span className={`badge text-xs ${e.status === 'completed' ? 'badge-beginner' : 'badge-intermediate'}`}>
                    {e.status}
                  </span>
                </div>
                <ChevronRight size={18} className="text-slate-600 group-hover:text-gold transition-colors shrink-0" />
              </Link>
            ))}

            {enrollments.length > 0 && (
              <Link to="/courses" className="btn-outline text-sm">
                Browse more courses <ChevronRight size={15} />
              </Link>
            )}
          </div>
        ) : (
          <div className="space-y-4 fade-up">
            {webinars.length === 0 ? (
              <div className="card p-10 text-center">
                <Video size={40} className="mx-auto text-slate-600 mb-4" />
                <p className="text-slate-400 mb-6">No webinar registrations yet.</p>
                <Link to="/webinars" className="btn-gold text-sm">Browse Webinars</Link>
              </div>
            ) : webinars.map(r => (
              <Link key={r.id} to={`/webinars/${r.webinars.slug}`}
                className="card p-5 flex items-center gap-5 group">
                <div className="w-14 h-14 rounded-xl bg-gold/10 border border-gold/20 flex items-center justify-center shrink-0">
                  <Video size={22} className="text-gold/60" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-display font-semibold text-white group-hover:text-gold transition-colors truncate">
                    {r.webinars.title}
                  </p>
                  <p className="text-xs text-slate-500 mt-1 flex items-center gap-1.5">
                    <Calendar size={11} />
                    {format(new Date(r.webinars.scheduled_at), 'MMM d, yyyy · HH:mm')} UTC
                  </p>
                </div>
                <span className={`badge shrink-0 ${r.webinars.status === 'completed'
                  ? r.attended ? 'badge-beginner' : 'badge-intermediate'
                  : 'badge-intermediate'}`}>
                  {r.webinars.status === 'completed' ? (r.attended ? 'Attended' : 'Missed') : 'Upcoming'}
                </span>
                <ChevronRight size={18} className="text-slate-600 group-hover:text-gold transition-colors shrink-0" />
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
