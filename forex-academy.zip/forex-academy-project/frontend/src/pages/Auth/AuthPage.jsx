import { useState, useEffect } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { signIn, signUp } from '../../lib/supabase'
import { useAuth } from '../../context/AuthContext'
import { TrendingUp, Eye, EyeOff, ArrowLeft } from 'lucide-react'
import toast from 'react-hot-toast'

export default function AuthPage() {
  const [params] = useSearchParams()
  const [isSignUp, setIsSignUp] = useState(params.get('tab') === 'signup')
  const [showPw, setShowPw] = useState(false)
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({ email:'', password:'', fullName:'' })
  const navigate = useNavigate()
  const { user } = useAuth()

  useEffect(() => { if (user) navigate('/dashboard') }, [user, navigate])

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }))

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      if (isSignUp) {
        const { error } = await signUp(form.email, form.password, form.fullName)
        if (error) throw error
        toast.success('Account created! Check your email to confirm.')
        setIsSignUp(false)
      } else {
        const { error } = await signIn(form.email, form.password)
        if (error) throw error
        toast.success('Welcome back!')
        navigate('/dashboard')
      }
    } catch (err) {
      toast.error(err.message || 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="bg-navy min-h-screen flex flex-col items-center justify-center px-4 py-12">
      {/* Brand */}
      <Link to="/" className="flex items-center gap-2.5 mb-10">
        <div className="w-9 h-9 rounded-xl bg-gold-shine flex items-center justify-center shadow-gold">
          <TrendingUp size={18} className="text-navy" strokeWidth={2.5} />
        </div>
        <span className="font-display font-bold text-xl text-white">
          Forex<span className="text-gold">Academy</span>
        </span>
      </Link>

      <div className="w-full max-w-md">
        <div className="card p-8">
          <h1 className="text-2xl font-display font-bold text-white mb-1">
            {isSignUp ? 'Create your account' : 'Welcome back'}
          </h1>
          <p className="text-sm text-slate-400 mb-8">
            {isSignUp
              ? 'Start your journey to consistent profitability.'
              : 'Sign in to continue your learning.'}
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            {isSignUp && (
              <div>
                <label className="text-xs font-semibold text-slate-400 block mb-1.5">Full Name</label>
                <input type="text" value={form.fullName} onChange={set('fullName')}
                  placeholder="Marco Rivera" className="input text-sm" required />
              </div>
            )}

            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1.5">Email</label>
              <input type="email" value={form.email} onChange={set('email')}
                placeholder="you@example.com" className="input text-sm" required />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1.5">Password</label>
              <div className="relative">
                <input type={showPw ? 'text' : 'password'} value={form.password} onChange={set('password')}
                  placeholder="At least 6 characters" className="input text-sm pr-10" required minLength={6} />
                <button type="button" onClick={() => setShowPw(p => !p)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors">
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <button type="submit" disabled={loading}
              className="btn-gold w-full justify-center mt-2 disabled:opacity-60">
              {loading ? 'Please wait…' : isSignUp ? 'Create Free Account' : 'Sign In'}
            </button>
          </form>

          <div className="divider-gold" />

          <button onClick={() => setIsSignUp(p => !p)}
            className="w-full text-center text-sm text-slate-400 hover:text-white transition-colors">
            {isSignUp
              ? <>Already have an account? <span className="text-gold font-semibold">Sign in</span></>
              : <>No account yet? <span className="text-gold font-semibold">Create one free</span></>}
          </button>
        </div>

        <Link to="/" className="flex items-center justify-center gap-1.5 mt-6 text-xs text-slate-500 hover:text-slate-300 transition-colors">
          <ArrowLeft size={13} /> Back to homepage
        </Link>
      </div>
    </div>
  )
}
