import { Link } from 'react-router-dom'
import { ArrowLeft, TrendingUp } from 'lucide-react'

export default function NotFound() {
  return (
    <div className="bg-navy min-h-screen flex flex-col items-center justify-center px-4 text-center">
      <div className="w-16 h-16 rounded-2xl bg-gold/10 border border-gold/20 flex items-center justify-center mb-6">
        <TrendingUp size={30} className="text-gold" />
      </div>
      <h1 className="text-7xl font-display font-bold text-gold mb-2">404</h1>
      <p className="text-xl font-display font-semibold text-white mb-2">Page not found</p>
      <p className="text-slate-400 mb-8 max-w-xs">This page might have moved or doesn't exist. Let's get you back on track.</p>
      <Link to="/" className="btn-gold">
        <ArrowLeft size={17} /> Back to Home
      </Link>
    </div>
  )
}
