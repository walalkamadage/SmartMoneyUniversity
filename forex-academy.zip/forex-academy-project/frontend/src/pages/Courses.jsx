import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { getAllCourses } from '../lib/supabase'
import { BarChart2, Clock, Users, Star, Search, SlidersHorizontal } from 'lucide-react'

const LEVELS = ['all', 'beginner', 'intermediate', 'advanced']
const TOPICS = ['All Topics', 'Price Action', 'Risk Management', 'Scalping', 'Swing Trading', 'ICT / Smart Money', 'Fundamentals']

// Placeholder courses shown when DB is empty
const PLACEHOLDER_COURSES = [
  { id:'p1', title:'Forex Foundations', slug:'forex-foundations', description:'Master the absolute basics: currency pairs, pips, spreads, lot sizes, and placing your first demo trade.', level:'beginner', student_count:842, total_lessons:14, duration_hours:6, rating:4.9, profiles:{ full_name:'Marco Rivera' } },
  { id:'p2', title:'Candlestick Psychology', slug:'candlestick-psychology', description:'Decode what candles are actually telling you — buyer/seller pressure, momentum, and exhaustion patterns.', level:'beginner', student_count:631, total_lessons:10, duration_hours:4, rating:4.8, profiles:{ full_name:'Sarah Chen' } },
  { id:'p3', title:'Support & Resistance Mastery', slug:'support-resistance', description:'Learn to identify key levels, understand why they work, and use them to time entries and exits with precision.', level:'intermediate', student_count:521, total_lessons:18, duration_hours:9, rating:4.9, profiles:{ full_name:'Marco Rivera' } },
  { id:'p4', title:'Price Action Trading System', slug:'price-action-system', description:'A complete system based purely on raw price — no indicators, no guesswork, just structure and order flow.', level:'intermediate', student_count:467, total_lessons:22, duration_hours:12, rating:5.0, profiles:{ full_name:'Yuki Tanaka' } },
  { id:'p5', title:'Risk & Trade Management', slug:'risk-management', description:'Position sizing, R-multiples, drawdown limits, and the psychological discipline that separates winners from losers.', level:'intermediate', student_count:389, total_lessons:16, duration_hours:8, rating:4.9, profiles:{ full_name:'Sarah Chen' } },
  { id:'p6', title:'ICT Concepts & Smart Money', slug:'ict-smart-money', description:'Institutional order flow, liquidity sweeps, order blocks, fair-value gaps, and optimal trade entries.', level:'advanced', student_count:314, total_lessons:31, duration_hours:18, rating:4.8, profiles:{ full_name:'Yuki Tanaka' } },
]

function CourseCard({ course }) {
  return (
    <Link to={`/courses/${course.slug}`} className="card overflow-hidden block group">
      {/* Thumbnail */}
      <div className="h-40 bg-gradient-to-br from-navy-mid to-gold/10 border-b border-gold relative flex items-center justify-center">
        <BarChart2 size={44} className="text-gold/25 group-hover:text-gold/45 transition-colors duration-300" />
        <span className={`badge absolute top-3 right-3 badge-${course.level}`}>{course.level}</span>
      </div>

      {/* Body */}
      <div className="p-5 flex flex-col gap-3">
        <h3 className="font-display font-semibold text-white group-hover:text-gold transition-colors line-clamp-2">
          {course.title}
        </h3>
        <p className="text-sm text-slate-400 line-clamp-2 leading-relaxed">{course.description}</p>

        {/* Instructor */}
        {course.profiles && (
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-gold-shine flex items-center justify-center text-navy text-xs font-bold font-display">
              {course.profiles.full_name?.[0]}
            </div>
            <span className="text-xs text-slate-500">{course.profiles.full_name}</span>
          </div>
        )}

        {/* Rating */}
        {course.rating > 0 && (
          <div className="flex items-center gap-1.5">
            <Star size={13} className="fill-gold text-gold" />
            <span className="text-sm font-semibold text-gold">{course.rating}</span>
            <span className="text-xs text-slate-500">({course.total_ratings || '—'})</span>
          </div>
        )}

        {/* Meta */}
        <div className="flex items-center justify-between pt-3 border-t border-gold text-xs text-slate-500">
          <span className="flex items-center gap-1.5"><Clock size={12} /> {course.duration_hours}h</span>
          <span className="flex items-center gap-1.5"><BarChart2 size={12} /> {course.total_lessons} lessons</span>
          <span className="flex items-center gap-1.5"><Users size={12} /> {(course.student_count||0).toLocaleString()}</span>
        </div>
      </div>
    </Link>
  )
}

export default function Courses() {
  const [courses, setCourses] = useState([])
  const [loading, setLoading] = useState(true)
  const [level, setLevel] = useState('all')
  const [query, setQuery] = useState('')

  useEffect(() => {
    const fetch = async () => {
      setLoading(true)
      const filter = level === 'all' ? {} : { level }
      const { data } = await getAllCourses(filter)
      setCourses(data?.length ? data : PLACEHOLDER_COURSES)
      setLoading(false)
    }
    fetch()
  }, [level])

  const filtered = courses.filter(c =>
    query === '' || c.title.toLowerCase().includes(query.toLowerCase())
  )

  return (
    <div className="bg-navy min-h-screen">
      {/* Header */}
      <section className="pt-16 pb-10 px-4 border-b border-gold">
        <div className="max-w-7xl mx-auto">
          <p className="text-gold text-sm font-display font-semibold tracking-widest uppercase mb-3 fade-up">Courses</p>
          <h1 className="text-5xl font-display font-bold text-white mb-4 fade-up fade-up-delay-1">
            Learn to Trade Right
          </h1>
          <p className="text-slate-400 max-w-xl fade-up fade-up-delay-2">
            From your first trade to institutional-level strategy — pick where you are and progress at your pace.
          </p>
        </div>
      </section>

      {/* Filters */}
      <section className="sticky top-16 z-30 glass border-b border-gold py-3 px-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row gap-3 items-start sm:items-center">
          {/* Search */}
          <div className="relative flex-1 max-w-xs">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search courses…"
              className="input pl-9 py-2 text-sm"
            />
          </div>

          {/* Level filter */}
          <div className="flex gap-2 flex-wrap">
            {LEVELS.map(l => (
              <button key={l} onClick={() => setLevel(l)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-display font-semibold capitalize transition-all ${
                  level === l
                    ? 'bg-gold-shine text-navy shadow-gold'
                    : 'glass text-slate-400 hover:text-white'
                }`}>
                {l}
              </button>
            ))}
          </div>

          <span className="text-xs text-slate-500 ml-auto hidden sm:block">
            <SlidersHorizontal size={13} className="inline mr-1" />
            {filtered.length} course{filtered.length !== 1 ? 's' : ''}
          </span>
        </div>
      </section>

      {/* Grid */}
      <section className="py-12 px-4">
        <div className="max-w-7xl mx-auto">
          {loading ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {Array.from({length:6}).map((_,i) => (
                <div key={i} className="card h-80 animate-pulse bg-white/5" />
              ))}
            </div>
          ) : filtered.length > 0 ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {filtered.map(c => <CourseCard key={c.id} course={c} />)}
            </div>
          ) : (
            <div className="text-center py-20">
              <BarChart2 size={48} className="mx-auto text-slate-600 mb-4" />
              <p className="text-slate-400">No courses match your search.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
