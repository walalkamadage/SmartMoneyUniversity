import { useState, useEffect } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { getCourseBySlug, enrollCourse } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { ArrowLeft, BookOpen, Clock, Users, Star, CheckCircle, Lock, PlayCircle, ChevronDown, ChevronUp } from 'lucide-react'
import toast from 'react-hot-toast'

const PLACEHOLDER = {
  id:'c1', title:'Price Action Mastery', slug:'price-action-system',
  description:`Learn to read the market purely through price — no indicators, no complex systems.\n\nThis course teaches you how professionals identify high-probability trade setups by understanding market structure, candlestick behavior, and institutional order flow.\n\nYou'll finish with a clear, rules-based system you can apply immediately on any pair or timeframe.`,
  level:'intermediate', duration_hours:12, total_lessons:22, student_count:521, rating:5.0, total_ratings:87,
  profiles:{ id:'i1', full_name:'Marco Rivera', bio:'10+ years professional forex trader. Former prop desk analyst with a focus on price action and market structure.' },
  lessons:[
    { id:'l1', title:'Why Indicators Fail', lesson_order:1, duration_minutes:18, is_free_preview:true },
    { id:'l2', title:'Market Structure Fundamentals', lesson_order:2, duration_minutes:24, is_free_preview:true },
    { id:'l3', title:'Reading Candlestick Pressure', lesson_order:3, duration_minutes:21, is_free_preview:false },
    { id:'l4', title:'Support & Resistance That Matters', lesson_order:4, duration_minutes:32, is_free_preview:false },
    { id:'l5', title:'Trend vs Range Identification', lesson_order:5, duration_minutes:28, is_free_preview:false },
    { id:'l6', title:'Break of Structure (BOS)', lesson_order:6, duration_minutes:35, is_free_preview:false },
    { id:'l7', title:'Entry Patterns: Pin Bars & Engulfing', lesson_order:7, duration_minutes:40, is_free_preview:false },
    { id:'l8', title:'Stop Loss Placement Logic', lesson_order:8, duration_minutes:22, is_free_preview:false },
  ],
  course_reviews:[
    { id:'r1', rating:5, review_text:'The BOS lesson completely changed how I see the market. Worth ten times the price.', user_id:'u1' },
    { id:'r2', rating:5, review_text:'Crystal clear explanations. I finally understand why my indicator signals were always late.', user_id:'u2' },
    { id:'r3', rating:5, review_text:'Marco\'s teaching style is exceptional. Complex ideas made simple without dumbing them down.', user_id:'u3' },
  ],
}

const WHAT_YOU_LL_LEARN = [
  'Identify market structure on any timeframe',
  'Read candlestick pressure without indicators',
  'Spot high-probability entry and exit zones',
  'Apply a rules-based system for consistent setups',
  'Manage trades using structure-based stop losses',
  'Adapt your strategy to trending and ranging markets',
]

export default function CourseDetail() {
  const { slug } = useParams()
  const navigate = useNavigate()
  const { user } = useAuth()
  const [course, setCourse] = useState(null)
  const [loading, setLoading] = useState(true)
  const [enrolled, setEnrolled] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [currOpen, setCurrOpen] = useState(false)

  useEffect(() => {
    const fetch = async () => {
      const { data } = await getCourseBySlug(slug)
      setCourse(data || PLACEHOLDER)
      setLoading(false)
    }
    fetch()
  }, [slug])

  const handleEnroll = async () => {
    if (!user) { navigate('/auth'); return }
    setSubmitting(true)
    const { error } = await enrollCourse(user.id, course.id)
    if (error) {
      if (error.code === '23505') { toast.success('Already enrolled!'); setEnrolled(true) }
      else toast.error('Enrollment failed')
    } else {
      setEnrolled(true)
      toast.success('Enrolled! Start learning below.')
    }
    setSubmitting(false)
  }

  if (loading) return (
    <div className="bg-navy min-h-screen flex items-center justify-center">
      <div className="w-8 h-8 rounded-full border-2 border-gold border-t-transparent animate-spin" />
    </div>
  )

  const c = course

  return (
    <div className="bg-navy min-h-screen">
      <div className="max-w-6xl mx-auto px-4 py-10">
        <Link to="/courses" className="inline-flex items-center gap-2 text-slate-400 hover:text-gold text-sm mb-8 transition-colors">
          <ArrowLeft size={16} /> Back to Courses
        </Link>

        <div className="grid lg:grid-cols-3 gap-10">
          {/* Main content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Header */}
            <div>
              <div className="flex items-center gap-3 mb-4">
                <span className={`badge badge-${c.level}`}>{c.level}</span>
                {c.rating > 0 && (
                  <span className="flex items-center gap-1 text-sm">
                    <Star size={14} className="fill-gold text-gold" />
                    <span className="font-semibold text-gold">{c.rating}</span>
                    <span className="text-slate-500">({c.total_ratings} reviews)</span>
                  </span>
                )}
                <span className="text-sm text-slate-500 flex items-center gap-1">
                  <Users size={13} /> {(c.student_count||0).toLocaleString()} students
                </span>
              </div>
              <h1 className="text-3xl sm:text-4xl font-display font-bold text-white leading-tight mb-4">{c.title}</h1>
              <p className="text-slate-400 leading-relaxed whitespace-pre-line">{c.description}</p>
            </div>

            {/* What you'll learn */}
            <div className="card p-6">
              <h2 className="font-display font-semibold text-white mb-4">What you'll learn</h2>
              <div className="grid sm:grid-cols-2 gap-3">
                {WHAT_YOU_LL_LEARN.map(item => (
                  <div key={item} className="flex items-start gap-2.5 text-sm text-slate-300">
                    <CheckCircle size={15} className="text-green-400 mt-0.5 shrink-0" />
                    {item}
                  </div>
                ))}
              </div>
            </div>

            {/* Curriculum */}
            {c.lessons && c.lessons.length > 0 && (
              <div>
                <button onClick={() => setCurrOpen(p => !p)}
                  className="flex items-center justify-between w-full mb-4">
                  <h2 className="font-display font-semibold text-white text-xl">
                    Curriculum <span className="text-slate-500 text-base font-body font-normal">({c.lessons.length} lessons)</span>
                  </h2>
                  {currOpen ? <ChevronUp size={18} className="text-gold" /> : <ChevronDown size={18} className="text-gold" />}
                </button>

                <div className="space-y-2">
                  {(currOpen ? c.lessons : c.lessons.slice(0,5)).sort((a,b) => a.lesson_order - b.lesson_order).map(l => (
                    <div key={l.id}
                      className="flex items-center gap-3 p-4 border border-gold rounded-xl hover:bg-white/3 transition-colors">
                      <div className="w-6 h-6 rounded-full bg-gold/10 border border-gold/20 flex items-center justify-center text-gold text-xs font-bold font-display shrink-0">
                        {l.lesson_order}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm text-white font-medium">{l.title}</p>
                        <p className="text-xs text-slate-500">{l.duration_minutes} min</p>
                      </div>
                      {l.is_free_preview
                        ? <span className="flex items-center gap-1 text-xs text-green-400"><PlayCircle size={13} /> Preview</span>
                        : <Lock size={13} className="text-slate-600" />
                      }
                    </div>
                  ))}
                  {!currOpen && c.lessons.length > 5 && (
                    <button onClick={() => setCurrOpen(true)} className="text-sm text-gold hover:text-gold-light transition-colors pt-2">
                      + {c.lessons.length - 5} more lessons
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Reviews */}
            {c.course_reviews?.length > 0 && (
              <div>
                <h2 className="font-display font-semibold text-white mb-5 text-xl">Student Reviews</h2>
                <div className="space-y-4">
                  {c.course_reviews.map(r => (
                    <div key={r.id} className="card p-5 space-y-2">
                      <div className="flex gap-0.5">
                        {Array.from({length: r.rating}).map((_,i) => (
                          <Star key={i} size={13} className="fill-gold text-gold" />
                        ))}
                      </div>
                      <p className="text-sm text-slate-300">"{r.review_text}"</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div>
            <div className="card p-6 space-y-5 sticky top-24">
              {/* Stats */}
              <div className="grid grid-cols-2 gap-3 text-sm">
                {[
                  { icon: BookOpen, label:'Lessons', val:c.total_lessons },
                  { icon: Clock,    label:'Duration', val:`${c.duration_hours}h` },
                  { icon: Users,    label:'Students', val:(c.student_count||0).toLocaleString() },
                  { icon: Star,     label:'Rating', val:c.rating > 0 ? `${c.rating} ★` : '—' },
                ].map(({ icon: Icon, label, val }) => (
                  <div key={label} className="flex items-center gap-2 text-xs">
                    <Icon size={13} className="text-gold" />
                    <span className="text-slate-400">{label}:</span>
                    <span className="text-white font-semibold">{val}</span>
                  </div>
                ))}
              </div>

              {/* Instructor */}
              {c.profiles && (
                <>
                  <div className="divider-gold" />
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-gold-shine flex items-center justify-center text-navy font-bold font-display shrink-0">
                      {c.profiles.full_name?.[0]}
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">Instructor</p>
                      <p className="font-semibold text-white text-sm">{c.profiles.full_name}</p>
                      <p className="text-xs text-slate-400 mt-1 line-clamp-2">{c.profiles.bio}</p>
                    </div>
                  </div>
                </>
              )}

              <div className="divider-gold" />

              {/* Enroll */}
              {enrolled ? (
                <div className="text-center space-y-3">
                  <CheckCircle size={32} className="mx-auto text-green-400" />
                  <p className="font-semibold text-white">You're enrolled!</p>
                  <Link to="/dashboard" className="btn-outline text-sm w-full justify-center">
                    Go to Dashboard
                  </Link>
                </div>
              ) : (
                <>
                  <p className="text-center">
                    <span className="text-3xl font-display font-bold text-gold">Free</span>
                    <span className="text-sm text-slate-500 ml-2">no credit card</span>
                  </p>
                  <button onClick={handleEnroll} disabled={submitting}
                    className="btn-gold w-full justify-center disabled:opacity-60">
                    {submitting ? 'Enrolling…' : 'Enroll Now — Free'}
                  </button>
                  {!user && (
                    <p className="text-center text-xs text-slate-500">
                      <Link to="/auth" className="text-gold hover:underline">Create a free account</Link> to get started
                    </p>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
