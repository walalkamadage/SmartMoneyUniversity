import { Link } from 'react-router-dom'
import { ArrowRight, TrendingUp, Users, Zap, Star, PlayCircle, ChevronRight, BarChart2, Shield, Globe } from 'lucide-react'

const PAIRS = [
  { pair:'EUR/USD', price:'1.0842', chg:'+0.18%', up:true },
  { pair:'GBP/USD', price:'1.2634', chg:'+0.05%', up:true },
  { pair:'USD/JPY', price:'149.62', chg:'-0.22%', up:false },
  { pair:'AUD/USD', price:'0.6418', chg:'+0.11%', up:true },
  { pair:'USD/CAD', price:'1.3581', chg:'-0.09%', up:false },
  { pair:'USD/CHF', price:'0.9102', chg:'+0.03%', up:true },
  { pair:'NZD/USD', price:'0.5983', chg:'-0.14%', up:false },
  { pair:'EUR/GBP', price:'0.8581', chg:'+0.07%', up:true },
]

const TESTIMONIALS = [
  { name:'Aarav Mehta',    role:'Intermediate Trader', text:'The live webinars completely changed my approach to risk management. My drawdown dropped by 60% in three months.', stars:5 },
  { name:'Sofia Laurent',  role:'Beginner Student',    text:'I went from knowing nothing about forex to placing my first profitable trade in just six weeks. The community is incredibly supportive.', stars:5 },
  { name:'James Okonkwo',  role:'Advanced Trader',     text:'The institutional-level content here is genuinely rare. The ICT concepts course alone is worth ten times the price.', stars:5 },
]

const FEATURES = [
  { icon: BarChart2, title: 'Structured Curriculum',   desc: 'From pips and spreads to advanced order-flow analysis — a clear path for every level.' },
  { icon: Zap,       title: 'Live Trading Rooms',      desc: 'Watch professionals trade in real time and ask questions as markets move.' },
  { icon: Users,     title: 'Active Community',        desc: 'Forums, peer feedback, and a leaderboard that rewards consistent learners.' },
  { icon: Shield,    title: 'Risk-First Philosophy',   desc: 'Every course bakes in capital preservation so you survive long enough to thrive.' },
  { icon: Globe,     title: 'Trade Any Session',       desc: 'Content covers London, New York, and Asian sessions — trade the hours that suit you.' },
  { icon: Star,      title: 'Instructor Mentorship',   desc: 'Direct messaging with verified instructors and weekly group Q&A calls.' },
]

function TickerBar() {
  const items = [...PAIRS, ...PAIRS] // double for seamless loop
  return (
    <div className="overflow-hidden border-b border-gold py-2.5 bg-navy-mid/60">
      <div className="ticker-track">
        {items.map((p, i) => (
          <span key={i} className="flex items-center gap-3 px-8 text-sm whitespace-nowrap">
            <span className="font-display font-semibold text-white">{p.pair}</span>
            <span className="text-slate-300">{p.price}</span>
            <span className={p.up ? 'text-green-400' : 'text-red-400'}>{p.chg}</span>
            <span className="text-gold/30">|</span>
          </span>
        ))}
      </div>
    </div>
  )
}

function StarRating({ n = 5 }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: n }).map((_, i) => (
        <Star key={i} size={13} className="fill-gold text-gold" />
      ))}
    </div>
  )
}

export default function Home() {
  return (
    <div className="bg-navy min-h-screen">
      <TickerBar />

      {/* ── Hero ── */}
      <section className="relative pt-24 pb-20 px-4 overflow-hidden">
        {/* radial glow */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[500px] bg-gold/5 rounded-full blur-3xl" />
        </div>

        <div className="max-w-4xl mx-auto text-center relative">
          <div className="inline-flex items-center gap-2 glass rounded-full px-4 py-2 text-sm text-gold mb-8 fade-up">
            <TrendingUp size={14} />
            <span>2,500+ traders enrolled this year</span>
          </div>

          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-display font-bold text-white leading-tight mb-6 fade-up fade-up-delay-1">
            Trade Forex<br /><span className="text-gold">With Conviction</span>
          </h1>

          <p className="text-lg text-slate-400 max-w-2xl mx-auto mb-10 fade-up fade-up-delay-2">
            Structured courses, live webinar rooms, and an engaged community of traders — everything you need to go from uncertain to consistently profitable.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center fade-up fade-up-delay-3">
            <Link to="/courses" className="btn-gold text-base">
              Start Learning Free <ArrowRight size={18} />
            </Link>
            <Link to="/webinars" className="btn-outline text-base">
              <PlayCircle size={18} /> Watch a Live Session
            </Link>
          </div>

          {/* Social proof strip */}
          <div className="mt-14 flex flex-wrap justify-center gap-8 fade-up fade-up-delay-3">
            {[
              { n: '2,500+', l: 'Active Students' },
              { n: '48',     l: 'Courses' },
              { n: '120+',   l: 'Live Webinars / yr' },
              { n: '4.9★',  l: 'Average Rating' },
            ].map(s => (
              <div key={s.l} className="text-center">
                <p className="text-3xl font-display font-bold text-gold">{s.n}</p>
                <p className="text-xs text-slate-500 mt-0.5">{s.l}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Features ── */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-14">
            <p className="text-gold text-sm font-display font-semibold tracking-widest uppercase mb-3">Why ForexAcademy</p>
            <h2 className="text-4xl font-display font-bold text-white">Built for serious traders</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {FEATURES.map(({ icon: Icon, title, desc }) => (
              <div key={title} className="card p-6 group">
                <div className="w-11 h-11 rounded-xl bg-gold/10 border border-gold/20 flex items-center justify-center mb-4 group-hover:bg-gold/20 transition-colors">
                  <Icon size={20} className="text-gold" />
                </div>
                <h3 className="font-display font-semibold text-white mb-2">{title}</h3>
                <p className="text-sm text-slate-400 leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Course preview ── */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-end justify-between mb-10">
            <div>
              <p className="text-gold text-sm font-display font-semibold tracking-widest uppercase mb-2">Courses</p>
              <h2 className="text-3xl font-display font-bold text-white">Popular right now</h2>
            </div>
            <Link to="/courses" className="flex items-center gap-1 text-sm text-gold hover:text-gold-light transition-colors">
              View all <ChevronRight size={15} />
            </Link>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {[
              { title:'Forex Foundations', level:'beginner',     students:842, lessons:14, desc:'Master pips, spreads, currency pairs, and the basics of placing your first trade.' },
              { title:'Price Action Mastery', level:'intermediate', students:521, lessons:22, desc:'Read candles, spot structures, and trade market movements without relying on indicators.' },
              { title:'ICT & Smart Money',  level:'advanced',    students:314, lessons:31, desc:'Institutional order-flow, liquidity sweeps, and fair-value gaps — trade like the banks.' },
            ].map(c => (
              <Link key={c.title} to="/courses" className="card overflow-hidden block group">
                <div className="h-36 bg-gradient-to-br from-navy-mid to-gold/10 flex items-center justify-center border-b border-gold relative">
                  <BarChart2 size={42} className="text-gold/30 group-hover:text-gold/50 transition-colors" />
                  <span className={`badge absolute top-3 right-3 badge-${c.level}`}>{c.level}</span>
                </div>
                <div className="p-5">
                  <h3 className="font-display font-semibold text-white mb-2 group-hover:text-gold transition-colors">{c.title}</h3>
                  <p className="text-sm text-slate-400 mb-4 line-clamp-2">{c.desc}</p>
                  <div className="flex justify-between text-xs text-slate-500">
                    <span>{c.lessons} lessons</span>
                    <span>{c.students.toLocaleString()} students</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── Testimonials ── */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-14">
            <p className="text-gold text-sm font-display font-semibold tracking-widest uppercase mb-3">Testimonials</p>
            <h2 className="text-3xl font-display font-bold text-white">What our traders say</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-5">
            {TESTIMONIALS.map(t => (
              <div key={t.name} className="card p-6 flex flex-col gap-4">
                <StarRating n={t.stars} />
                <p className="text-sm text-slate-300 leading-relaxed flex-1">"{t.text}"</p>
                <div>
                  <p className="font-semibold text-white text-sm">{t.name}</p>
                  <p className="text-xs text-slate-500">{t.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="py-20 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <div className="card p-12 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-radial from-gold/8 to-transparent pointer-events-none" />
            <h2 className="text-4xl font-display font-bold text-white mb-4 relative">Ready to level up?</h2>
            <p className="text-slate-400 mb-8 relative">Join the community and get immediate access to free courses, the discussion forum, and our next live webinar.</p>
            <Link to="/auth?tab=signup" className="btn-gold text-base relative">
              Create Free Account <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
