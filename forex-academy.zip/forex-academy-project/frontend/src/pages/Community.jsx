import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { getForumPosts, createForumPost } from '../lib/supabase'
import { MessageSquare, Plus, Pin, Tag, TrendingUp, ChevronRight, Award, Flame, Trophy } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'
import toast from 'react-hot-toast'

const PLACEHOLDER_POSTS = [
  { id:'p1', title:'My journey from blowing 3 accounts to becoming consistent', content:'After losing $12,000 across three demo accounts I finally understood what was wrong — I was overtrading...', category:'discussion', is_pinned:true,  reply_count:24, view_count:412, created_at: new Date(Date.now()-2*86400000).toISOString(), profiles:{ full_name:'James Okonkwo', avatar_url:null } },
  { id:'p2', title:'Can someone explain the NY killzone timing?', content:'I keep hearing about the New York killzone but I\'m confused about the exact hours and why it matters...', category:'question',    is_pinned:false, reply_count:11, view_count:189, created_at: new Date(Date.now()-4*86400000).toISOString(), profiles:{ full_name:'Sofia Laurent',  avatar_url:null } },
  { id:'p3', title:'Weekly trade journal — Week 21 (GBP/USD swings)', content:'Sharing my full week of trades for accountability. Total outcome: +3.4R from 4 trades taken...', category:'discussion', is_pinned:false, reply_count:7,  view_count:95,  created_at: new Date(Date.now()-1*86400000).toISOString(), profiles:{ full_name:'Aarav Mehta',    avatar_url:null } },
  { id:'p4', title:'Order block vs demand zone — what\'s the difference?', content:'I\'ve been studying ICT content but keep getting confused about when to use order blocks vs supply/demand zones...', category:'question', is_pinned:false, reply_count:15, view_count:231, created_at: new Date(Date.now()-6*86400000).toISOString(), profiles:{ full_name:'Maria Santos',   avatar_url:null } },
  { id:'p5', title:'Free resources that actually helped me — the full list', content:'After 18 months of studying, here are the genuinely free resources that made the biggest difference to my trading...', category:'discussion', is_pinned:false, reply_count:33, view_count:680, created_at: new Date(Date.now()-8*86400000).toISOString(), profiles:{ full_name:'James Okonkwo',  avatar_url:null } },
  { id:'p6', title:'Risk management question — 1% per trade or 1% account risk?', content:'Quick question: when people say "risk 1%" do they mean 1% of the initial deposit or 1% of the current balance?', category:'question', is_pinned:false, reply_count:9, view_count:143, created_at: new Date(Date.now()-3*86400000).toISOString(), profiles:{ full_name:'Lena Müller',    avatar_url:null } },
]

const LEADERBOARD = [
  { name:'James Okonkwo', score:1240, posts:34, icon:Trophy },
  { name:'Aarav Mehta',   score:980,  posts:28, icon:Award },
  { name:'Sofia Laurent', score:720,  posts:19, icon:Flame },
]

const CATS = ['All', 'Discussion', 'Question', 'Announcement']
const CAT_BADGE = { discussion:'badge-intermediate', question:'badge-beginner', announcement:'badge-advanced' }

function PostCard({ post }) {
  return (
    <div className="card p-5 flex gap-4 group cursor-pointer hover:border-gold/40">
      {post.is_pinned && (
        <Pin size={14} className="text-gold mt-1 shrink-0" />
      )}
      <div className="flex-1 min-w-0">
        <div className="flex items-start gap-2 mb-2">
          <h3 className="font-display font-semibold text-white group-hover:text-gold transition-colors line-clamp-1 flex-1">
            {post.title}
          </h3>
          <span className={`badge shrink-0 ${CAT_BADGE[post.category] || 'badge-intermediate'}`}>
            {post.category}
          </span>
        </div>
        <p className="text-sm text-slate-400 line-clamp-2 mb-3">{post.content}</p>
        <div className="flex items-center gap-4 text-xs text-slate-500">
          {post.profiles && (
            <span className="flex items-center gap-1.5">
              <div className="w-4 h-4 rounded-full bg-gold-shine flex items-center justify-center text-navy text-[9px] font-bold font-display">
                {post.profiles.full_name?.[0]}
              </div>
              {post.profiles.full_name}
            </span>
          )}
          <span>{formatDistanceToNow(new Date(post.created_at), { addSuffix: true })}</span>
          <span className="flex items-center gap-1"><MessageSquare size={11} /> {post.reply_count}</span>
          <span>{post.view_count} views</span>
        </div>
      </div>
    </div>
  )
}

export default function Community() {
  const { user } = useAuth()
  const [posts, setPosts] = useState([])
  const [loading, setLoading] = useState(true)
  const [category, setCategory] = useState('All')
  const [showNew, setShowNew] = useState(false)
  const [form, setForm] = useState({ title:'', content:'', category:'discussion' })
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    const fetch = async () => {
      const { data } = await getForumPosts(null, 20)
      setPosts(data?.length ? data : PLACEHOLDER_POSTS)
      setLoading(false)
    }
    fetch()
  }, [])

  const filtered = posts.filter(p =>
    category === 'All' || p.category === category.toLowerCase()
  )

  const handlePost = async (e) => {
    e.preventDefault()
    if (!user) { toast.error('Sign in to post'); return }
    if (!form.title.trim() || !form.content.trim()) { toast.error('Fill in all fields'); return }
    setSubmitting(true)
    const { data, error } = await createForumPost(user.id, form.title, form.content, null, form.category)
    if (error) { toast.error('Failed to post'); }
    else {
      toast.success('Post created!')
      setShowNew(false)
      setForm({ title:'', content:'', category:'discussion' })
      // Prepend new post locally
      setPosts(p => [{ ...data, profiles:{ full_name: 'You' } }, ...p])
    }
    setSubmitting(false)
  }

  return (
    <div className="bg-navy min-h-screen">
      <div className="max-w-7xl mx-auto px-4 py-10">
        {/* Header */}
        <div className="flex items-start justify-between mb-10 fade-up">
          <div>
            <p className="text-gold text-sm font-display font-semibold tracking-widest uppercase mb-2">Community</p>
            <h1 className="text-4xl font-display font-bold text-white">Trading Forum</h1>
            <p className="text-slate-400 mt-2">Ask questions, share trades, and grow together.</p>
          </div>
          <button onClick={() => { if (!user) { toast.error('Sign in to post'); return } setShowNew(p => !p) }}
            className="btn-gold text-sm">
            <Plus size={16} /> New Post
          </button>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Posts */}
          <div className="lg:col-span-3 space-y-5">
            {/* New post form */}
            {showNew && (
              <div className="card p-6 space-y-4 fade-up">
                <h2 className="font-display font-semibold text-white">Create a new post</h2>
                <form onSubmit={handlePost} className="space-y-4">
                  <input value={form.title} onChange={e => setForm(f => ({...f, title:e.target.value}))}
                    placeholder="Post title…" className="input text-sm" />
                  <textarea value={form.content} onChange={e => setForm(f => ({...f, content:e.target.value}))}
                    placeholder="Share your thoughts, question, or trade…" rows={5}
                    className="input text-sm resize-none" />
                  <div className="flex items-center gap-3">
                    <select value={form.category} onChange={e => setForm(f => ({...f, category:e.target.value}))}
                      className="input text-sm w-auto">
                      <option value="discussion">Discussion</option>
                      <option value="question">Question</option>
                    </select>
                    <button type="submit" disabled={submitting} className="btn-gold text-sm">
                      {submitting ? 'Posting…' : 'Publish Post'}
                    </button>
                    <button type="button" onClick={() => setShowNew(false)} className="btn-ghost text-sm">
                      Cancel
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* Category filter */}
            <div className="flex gap-2 flex-wrap">
              {CATS.map(c => (
                <button key={c} onClick={() => setCategory(c)}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-display font-semibold transition-all ${
                    category === c ? 'bg-gold-shine text-navy shadow-gold' : 'glass text-slate-400 hover:text-white'
                  }`}>
                  {c}
                </button>
              ))}
            </div>

            {/* Posts list */}
            {loading ? (
              <div className="space-y-4">
                {Array.from({length:4}).map((_,i) => <div key={i} className="card h-28 animate-pulse bg-white/5" />)}
              </div>
            ) : (
              <div className="space-y-3">
                {filtered.map(p => <PostCard key={p.id} post={p} />)}
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Leaderboard */}
            <div className="card p-5">
              <p className="text-xs font-display font-semibold text-gold uppercase tracking-widest mb-4">
                🏆 Monthly Leaders
              </p>
              <div className="space-y-4">
                {LEADERBOARD.map((l, i) => {
                  const Icon = l.icon
                  return (
                    <div key={l.name} className="flex items-center gap-3">
                      <span className="w-6 text-center font-display font-bold text-slate-500 text-sm">{i+1}</span>
                      <div className="w-8 h-8 rounded-full bg-gold/10 border border-gold/20 flex items-center justify-center text-navy text-xs font-bold font-display text-gold">
                        <Icon size={15} className="text-gold" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm text-white font-medium">{l.name}</p>
                        <p className="text-xs text-slate-500">{l.posts} posts · {l.score} pts</p>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>

            {/* Quick links */}
            <div className="card p-5 space-y-2">
              <p className="text-xs font-display font-semibold text-gold uppercase tracking-widest mb-4">Explore</p>
              {[
                { label:'Browse Courses', href:'/courses', icon:TrendingUp },
                { label:'Upcoming Webinars', href:'/webinars', icon:MessageSquare },
              ].map(l => (
                <Link key={l.label} to={l.href}
                  className="flex items-center justify-between text-sm text-slate-400 hover:text-white py-2 transition-colors group">
                  <span className="flex items-center gap-2">
                    <l.icon size={14} className="text-gold/60" />
                    {l.label}
                  </span>
                  <ChevronRight size={14} className="group-hover:text-gold transition-colors" />
                </Link>
              ))}
            </div>

            {/* Guidelines */}
            <div className="card p-5">
              <p className="text-xs font-display font-semibold text-gold uppercase tracking-widest mb-3">Community Rules</p>
              <ul className="text-xs text-slate-400 space-y-2">
                {['Be respectful and constructive', 'No signal selling or self-promotion', 'Share trade ideas with analysis', 'Help others — pay it forward'].map(r => (
                  <li key={r} className="flex items-start gap-2">
                    <span className="text-gold mt-0.5">·</span> {r}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
