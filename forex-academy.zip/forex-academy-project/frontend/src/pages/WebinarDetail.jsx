import { useState, useEffect } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { getWebinarBySlug, registerWebinar } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { format, formatDistanceToNow } from 'date-fns'
import { ArrowLeft, Calendar, Clock, Users, Video, Radio, CheckCircle, Lock } from 'lucide-react'
import toast from 'react-hot-toast'

const PLACEHOLDER = {
  id:'w1', slug:'london-session-analysis', title:'London Session Live Trade — EUR/USD & GBP/JPY',
  description:`Join us for a full London open session where we trade live on EUR/USD and GBP/JPY.\n\nYou'll see our full process from start to finish: pre-session bias, identifying key levels, waiting for confirmation, placing trades, managing positions, and taking profit.\n\nThis is NOT a recorded example — everything happens live, in real time, with full commentary.`,
  topic:'price-action', scheduled_at: new Date(Date.now() + 1.5*24*60*60*1000).toISOString(),
  duration_minutes:90, attendee_count:143, is_free:true, status:'scheduled', recording_url:null,
  profiles:{ id:'i1', full_name:'Marco Rivera', bio:'10+ years trading forex. Former prop-desk analyst, now full-time educator.', avatar_url:null },
}

const WHAT_COVERED = [
  'Pre-session bias and daily outlook',
  'Identifying high-probability entry zones',
  'Live order placement with tight risk management',
  'Position sizing and scaling out',
  'Post-trade analysis and lessons learned',
]

export default function WebinarDetail() {
  const { slug } = useParams()
  const navigate = useNavigate()
  const { user } = useAuth()
  const [webinar, setWebinar] = useState(null)
  const [loading, setLoading] = useState(true)
  const [registered, setRegistered] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    const fetch = async () => {
      const { data } = await getWebinarBySlug(slug)
      setWebinar(data || PLACEHOLDER)
      setLoading(false)
    }
    fetch()
  }, [slug])

  const handleRegister = async () => {
    if (!user) { navigate('/auth'); return }
    setSubmitting(true)
    const { error } = await registerWebinar(user.id, webinar.id)
    if (error) {
      if (error.code === '23505') { toast.error('Already registered!') }
      else toast.error('Registration failed. Try again.')
    } else {
      setRegistered(true)
      toast.success('Registered! Check your email for details.')
    }
    setSubmitting(false)
  }

  if (loading) return (
    <div className="bg-navy min-h-screen flex items-center justify-center">
      <div className="w-8 h-8 rounded-full border-2 border-gold border-t-transparent animate-spin" />
    </div>
  )

  const w = webinar
  const isLive = w.status === 'live'
  const isCompleted = w.status === 'completed'

  return (
    <div className="bg-navy min-h-screen">
      <div className="max-w-5xl mx-auto px-4 py-10">
        <Link to="/webinars" className="inline-flex items-center gap-2 text-slate-400 hover:text-gold text-sm mb-8 transition-colors">
          <ArrowLeft size={16} /> Back to Webinars
        </Link>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main */}
          <div className="lg:col-span-2 space-y-8">
            {/* Status badge */}
            <div className="flex items-center gap-3">
              {isLive && (
                <span className="flex items-center gap-1.5 bg-red-500/20 border border-red-500/30 text-red-400 text-xs font-semibold px-3 py-1.5 rounded-full">
                  <Radio size={12} className="animate-pulse" /> LIVE NOW
                </span>
              )}
              {!isLive && !isCompleted && (
                <span className="flex items-center gap-1.5 text-xs font-semibold text-gold bg-gold/10 border border-gold/20 px-3 py-1.5 rounded-full">
                  in {formatDistanceToNow(new Date(w.scheduled_at))}
                </span>
              )}
              {isCompleted && <span className="badge badge-intermediate">Completed</span>}
              {w.is_free
                ? <span className="badge badge-beginner">Free</span>
                : <span className="badge badge-advanced">Paid</span>
              }
            </div>

            <h1 className="text-3xl sm:text-4xl font-display font-bold text-white leading-tight">{w.title}</h1>
            <p className="text-slate-400 text-sm leading-relaxed whitespace-pre-line">{w.description}</p>

            {/* What you'll see */}
            <div className="card p-6 space-y-4">
              <h2 className="font-display font-semibold text-white">What you'll see in this session</h2>
              <ul className="space-y-2.5">
                {WHAT_COVERED.map(item => (
                  <li key={item} className="flex items-start gap-3 text-sm text-slate-300">
                    <CheckCircle size={15} className="text-green-400 mt-0.5 shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            {/* Instructor */}
            {w.profiles && (
              <div className="card p-6 flex items-start gap-5">
                <div className="w-16 h-16 rounded-xl bg-gold-shine flex items-center justify-center text-navy text-2xl font-bold font-display shrink-0">
                  {w.profiles.full_name?.[0]}
                </div>
                <div>
                  <p className="text-xs font-display text-gold uppercase tracking-widest mb-1">Your Instructor</p>
                  <p className="font-display font-semibold text-white text-lg mb-2">{w.profiles.full_name}</p>
                  <p className="text-sm text-slate-400">{w.profiles.bio}</p>
                </div>
              </div>
            )}

            {/* Recording */}
            {isCompleted && w.recording_url && (
              <div className="card p-6 text-center">
                <Video size={40} className="mx-auto text-gold mb-3" />
                <p className="font-semibold text-white mb-4">Recording Available</p>
                <a href={w.recording_url} target="_blank" rel="noreferrer" className="btn-gold text-sm">
                  Watch Recording
                </a>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-5">
            <div className="card p-6 space-y-5 sticky top-24">
              {/* Schedule info */}
              <div className="space-y-3">
                {[
                  { icon: Calendar, label: 'Date', val: format(new Date(w.scheduled_at), 'EEEE, MMMM d, yyyy') },
                  { icon: Clock,    label: 'Time', val: `${format(new Date(w.scheduled_at), 'HH:mm')} UTC` },
                  { icon: Clock,    label: 'Duration', val: `${w.duration_minutes} minutes` },
                  { icon: Users,    label: 'Registered', val: `${w.attendee_count} traders` },
                ].map(({ icon: Icon, label, val }) => (
                  <div key={label} className="flex items-center gap-3 text-sm">
                    <div className="w-8 h-8 rounded-lg bg-gold/10 flex items-center justify-center shrink-0">
                      <Icon size={14} className="text-gold" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">{label}</p>
                      <p className="text-white font-medium">{val}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="divider-gold" />

              {isCompleted ? (
                w.recording_url ? (
                  <a href={w.recording_url} target="_blank" rel="noreferrer" className="btn-gold w-full justify-center text-sm">
                    <Video size={16} /> Watch Recording
                  </a>
                ) : (
                  <p className="text-center text-sm text-slate-500">Recording coming soon</p>
                )
              ) : registered ? (
                <div className="text-center space-y-2">
                  <CheckCircle size={32} className="mx-auto text-green-400" />
                  <p className="font-semibold text-white">You're registered!</p>
                  <p className="text-xs text-slate-400">We'll email you a reminder before the session starts.</p>
                </div>
              ) : (
                <>
                  <button
                    onClick={handleRegister}
                    disabled={submitting}
                    className="btn-gold w-full justify-center text-sm disabled:opacity-60">
                    {submitting ? 'Registering…' : w.is_free ? 'Register Free' : 'Get Your Ticket'}
                  </button>
                  {!user && (
                    <p className="text-center text-xs text-slate-500">
                      <Link to="/auth" className="text-gold hover:underline">Create a free account</Link> to register
                    </p>
                  )}
                  {!w.is_free && (
                    <div className="flex items-center gap-2 text-xs text-slate-500 justify-center">
                      <Lock size={12} />
                      <span>Payment will be handled on the next screen</span>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
