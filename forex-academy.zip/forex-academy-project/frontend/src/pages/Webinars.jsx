import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { getUpcomingWebinars } from '../lib/supabase'
import { Calendar, Clock, Users, Video, Radio, ChevronRight } from 'lucide-react'
import { formatDistanceToNow, format, isPast } from 'date-fns'

const PLACEHOLDER_WEBINARS = [
  { id:'w1', slug:'london-session-analysis', title:'London Session Live Trade — EUR/USD & GBP/JPY', description:'Watch a full London open session with real-time commentary on bias, entries, and risk management.', topic:'price-action', scheduled_at: new Date(Date.now() + 1.5*24*60*60*1000).toISOString(), duration_minutes:90, attendee_count:143, is_free:true, status:'scheduled', profiles:{ full_name:'Marco Rivera', avatar_url:null } },
  { id:'w2', slug:'risk-management-masterclass', title:'Risk Management Masterclass: Never Blow Another Account', description:'Deep dive into position sizing, max drawdown rules, and the mindset shifts that protect your capital long-term.', topic:'risk-management', scheduled_at: new Date(Date.now() + 3*24*60*60*1000).toISOString(), duration_minutes:60, attendee_count:98, is_free:true, status:'scheduled', profiles:{ full_name:'Sarah Chen', avatar_url:null } },
  { id:'w3', slug:'ict-order-blocks-live', title:'ICT Order Blocks & FVG — Live Market Application', description:'Identify institutional order blocks and fair value gaps on live charts across majors and indices.', topic:'ict', scheduled_at: new Date(Date.now() + 5*24*60*60*1000).toISOString(), duration_minutes:120, attendee_count:211, is_free:false, status:'scheduled', profiles:{ full_name:'Yuki Tanaka', avatar_url:null } },
  { id:'w4', slug:'swing-trading-weekly-outlook', title:'Weekly Market Outlook & Swing Trade Setups', description:'Every week we map out the key levels, bias, and potential swing trade setups across 10+ currency pairs.', topic:'swing-trading', scheduled_at: new Date(Date.now() + 7*24*60*60*1000).toISOString(), duration_minutes:45, attendee_count:267, is_free:true, status:'scheduled', profiles:{ full_name:'Marco Rivera', avatar_url:null } },
  { id:'w5', slug:'psychology-consistent-profits', title:'Trading Psychology: Breaking the Revenge-Trade Cycle', description:'Address the emotional patterns that destroy consistency — overtrading, FOMO, and loss aversion.', topic:'psychology', scheduled_at: new Date(Date.now() + 10*24*60*60*1000).toISOString(), duration_minutes:60, attendee_count:76, is_free:true, status:'scheduled', profiles:{ full_name:'Sarah Chen', avatar_url:null } },
  { id:'w6', slug:'scalping-new-york-open', title:'New York Open Scalping Strategy — Live Session', description:'High-probability scalp setups around the NY open — tight stops, defined targets, and fast execution.', topic:'scalping', scheduled_at: new Date(Date.now() + 12*24*60*60*1000).toISOString(), duration_minutes:75, attendee_count:134, is_free:false, status:'scheduled', profiles:{ full_name:'Yuki Tanaka', avatar_url:null } },
]

function Countdown({ target }) {
  const dist = formatDistanceToNow(new Date(target), { addSuffix: false })
  return (
    <span className="text-xs font-semibold text-gold bg-gold/10 border border-gold/20 px-2.5 py-1 rounded-full">
      in {dist}
    </span>
  )
}

function WebinarCard({ w }) {
  return (
    <Link to={`/webinars/${w.slug}`} className="card overflow-hidden flex flex-col group">
      {/* Color band */}
      <div className="h-2 bg-gold-shine" />

      <div className="p-6 flex flex-col gap-4 flex-1">
        <div className="flex items-start justify-between gap-3">
          <h3 className="font-display font-semibold text-white group-hover:text-gold transition-colors line-clamp-2 text-base">
            {w.title}
          </h3>
          {w.is_free
            ? <span className="badge shrink-0 badge-beginner">Free</span>
            : <span className="badge shrink-0 badge-advanced">Paid</span>
          }
        </div>

        <p className="text-sm text-slate-400 line-clamp-2 leading-relaxed">{w.description}</p>

        {/* Instructor */}
        {w.profiles && (
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-gold-shine flex items-center justify-center text-navy text-xs font-bold font-display">
              {w.profiles.full_name?.[0]}
            </div>
            <span className="text-xs text-slate-500">{w.profiles.full_name}</span>
          </div>
        )}

        <div className="mt-auto pt-4 border-t border-gold flex items-center justify-between text-xs text-slate-500 gap-2 flex-wrap">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1.5">
              <Calendar size={12} />
              {format(new Date(w.scheduled_at), 'MMM d, HH:mm')} UTC
            </span>
            <span className="flex items-center gap-1.5">
              <Clock size={12} />
              {w.duration_minutes}min
            </span>
            <span className="flex items-center gap-1.5">
              <Users size={12} />
              {w.attendee_count}
            </span>
          </div>
          <Countdown target={w.scheduled_at} />
        </div>
      </div>
    </Link>
  )
}

export default function Webinars() {
  const [webinars, setWebinars] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('all') // all | free | paid

  useEffect(() => {
    const fetch = async () => {
      const { data } = await getUpcomingWebinars(20)
      setWebinars(data?.length ? data : PLACEHOLDER_WEBINARS)
      setLoading(false)
    }
    fetch()
  }, [])

  const filtered = webinars.filter(w =>
    filter === 'all' ? true : filter === 'free' ? w.is_free : !w.is_free
  )

  return (
    <div className="bg-navy min-h-screen">
      {/* Header */}
      <section className="pt-16 pb-10 px-4 border-b border-gold">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-2 mb-3 fade-up">
            <Radio size={14} className="text-red-400 animate-pulse" />
            <p className="text-red-400 text-sm font-display font-semibold tracking-widest uppercase">Live Webinars</p>
          </div>
          <h1 className="text-5xl font-display font-bold text-white mb-4 fade-up fade-up-delay-1">
            Trade With Us, Live
          </h1>
          <p className="text-slate-400 max-w-xl fade-up fade-up-delay-2">
            Register for upcoming live sessions. Ask questions in real time, watch live trades, and learn by doing.
          </p>
        </div>
      </section>

      {/* Filter bar */}
      <section className="sticky top-16 z-30 glass border-b border-gold py-3 px-4">
        <div className="max-w-7xl mx-auto flex items-center gap-3">
          {['all','free','paid'].map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-display font-semibold capitalize transition-all ${
                filter === f ? 'bg-gold-shine text-navy shadow-gold' : 'glass text-slate-400 hover:text-white'
              }`}>
              {f === 'all' ? 'All Sessions' : f === 'free' ? 'Free' : 'Paid'}
            </button>
          ))}
          <span className="ml-auto text-xs text-slate-500">
            <Video size={13} className="inline mr-1" />
            {filtered.length} upcoming
          </span>
        </div>
      </section>

      {/* Next webinar hero */}
      {!loading && filtered.length > 0 && (
        <section className="py-10 px-4">
          <div className="max-w-7xl mx-auto">
            <p className="text-xs font-display font-semibold text-gold uppercase tracking-widest mb-4">Next Session</p>
            <Link to={`/webinars/${filtered[0].slug}`}
              className="card overflow-hidden flex flex-col md:flex-row group">
              <div className="md:w-72 shrink-0 h-48 md:h-auto bg-gradient-to-br from-navy-mid to-gold/10 flex items-center justify-center border-b md:border-b-0 md:border-r border-gold">
                <Video size={56} className="text-gold/30 group-hover:text-gold/50 transition-colors" />
              </div>
              <div className="p-8 flex flex-col gap-4 flex-1">
                <div className="flex items-center gap-3">
                  <Radio size={14} className="text-red-400 animate-pulse" />
                  <span className="text-red-400 text-xs font-semibold">NEXT LIVE</span>
                  <Countdown target={filtered[0].scheduled_at} />
                </div>
                <h2 className="text-2xl font-display font-bold text-white group-hover:text-gold transition-colors">
                  {filtered[0].title}
                </h2>
                <p className="text-slate-400 line-clamp-2">{filtered[0].description}</p>
                <div className="flex items-center gap-4 text-sm text-slate-500 mt-auto">
                  <span>{format(new Date(filtered[0].scheduled_at), 'EEEE, MMM d · HH:mm')} UTC</span>
                  <span>{filtered[0].duration_minutes} min</span>
                  <span>{filtered[0].attendee_count} registered</span>
                </div>
                <span className="btn-gold self-start text-sm">
                  Register Now <ChevronRight size={16} />
                </span>
              </div>
            </Link>
          </div>
        </section>
      )}

      {/* All webinars */}
      <section className="py-6 pb-20 px-4">
        <div className="max-w-7xl mx-auto">
          <p className="text-xs font-display font-semibold text-slate-500 uppercase tracking-widest mb-6">All Upcoming Sessions</p>
          {loading ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {Array.from({length:6}).map((_,i) => <div key={i} className="card h-64 animate-pulse bg-white/5" />)}
            </div>
          ) : filtered.length > 1 ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {filtered.slice(1).map(w => <WebinarCard key={w.id} w={w} />)}
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-20">
              <Video size={48} className="mx-auto text-slate-600 mb-4" />
              <p className="text-slate-400">No sessions match this filter.</p>
            </div>
          ) : null}
        </div>
      </section>
    </div>
  )
}
